@extends('layouts.master')
@section('title', 'Inbound Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/report/inbound" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input size="16" type="text" value="{{$phone}}" name="phone" class="form-control">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="exampleI">In Groups</label><br>
                                    <select multiple name="groups[]" id="e1" style="width:370px" class="populate">
                                        @foreach($ingroups as $groups)
                                        <?php $uids = 'xx_xx,'.$ingroups1; $uid = $groups->group_id; ?>
                                        <option value="{{$groups->group_id}}" @if(strpos($uids, $uid) == true) selected="" @endif>{{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>

                            <div class="form-group col-md-3">
                                    <h4>Total <b>{{count($dial_logs)}}</b> records.</h4>
                            </div>
                            <input type="hidden" name="exportstatus" id="exportstatus" value="0">
                            <div class="form-group col-md-3 pull-right"><br>
                            <a href="#" class="btn btn-warning" onclick="exportexcel();"><i class="fa fa-arrows-alt"></i> Export</a>
                            <button type="submit" class="btn btn-primary" id="submitbtn"><i class="fa fa-search"></i> Search</button>
                            </div>

                            </section>
                        </form>
                    </div>
            </div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Inbound Report</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Phone</th>
                    <th>Ingroup</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Length</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($dial_logs) > 0)
                  @foreach($dial_logs as $log)
                    <?php
                    $listnames = App\VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
                    $listname =  'ListName';
                    if(count($listnames) > 0){
                       $listname =  $listnames[0]->list_name;
                    } 
                    ?>
                    <tr class="gradeX">
                    <td>{{$log->lead_id}}</td>
                    <td>{{$log->phone_number}}</td>
                    <td>{{$log->campaign_id}}</td>
                    <td>{{$log->call_date}}</td>
                    <td>@if($log->status == 'B') Busy @elseif($log->status == 'NA') No Answer @else {{$log->status}} @endif</td>
                    <td>{{$log->user}}</td>
                    <td>{{$listname}}</td>
                    <td>{{App\Average::toMinutes($log->length_in_sec)}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')
<script type="text/javascript">

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }

  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }
</script>

@stop
