<?php

$account = App\MKtargt::where('phone004','55551212')->first();
print_r($account);
echo "<br>++++++++++++++++ account +++++++++++<br>";
if($account){
$id_account = $account->magic;

$vehicles = App\MKvehic::join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->where('mk_00_vlink.ctmagic',$id_account)->first();
print_r($vehicles);
echo "<br>++++++++++++++++ vehicles +++++++++++<br>";

if($vehicles){
$vehid = $vehicles->magic;
$newst = App\MKnewst::where('vehmagic',$vehid)->first();
print_r($newst);
echo "<br>++++++++++++++++ newst +++++++++++<br>";
}

$vehhisty = App\MKhisty::where('prime',$vehid)->where('tarmagic',$id_account)->orderBy('DATE','desc')->first();
print_r($vehhisty);
echo "<br>++++++++++++++++ vehhisty +++++++++++<br>";
}

?>