<?php 
    $routeName = Request::route()->getName();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="ThemeBucket">

    <meta http-equiv=”X-UA-Compatible” content=”IE=EmulateIE9”>
    <meta http-equiv=”X-UA-Compatible” content=”IE=9”>

    <link rel="shortcut icon" href="{{asset('')}}/bucket/images/favicon.png">
    <title>List Dashboard</title>
    <!--Core CSS -->
    <link href="{{asset('')}}/bucket/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/js/jquery-ui/jquery-ui-1.10.1.custom.min.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/css/bootstrap-reset.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/js/jvector-map/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/css/clndr.css" rel="stylesheet">
    <!--clock css-->
    <link href="{{asset('')}}/bucket/js/css3clock/css/style.css" rel="stylesheet">
    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="{{asset('')}}/bucket/js/morris-chart/morris.css">
    <!-- Custom styles for this template -->
    <link href="{{asset('')}}/bucket/css/style.css" rel="stylesheet">
    <link href="{{asset('')}}/bucket/css/style-responsive.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]>
    <script src="{{asset('')}}/bucket/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="{{asset('')}}/bucket/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="{{asset('')}}/bucket/https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<section id="container">
@include('layouts.header')
@include('layouts.leftside')
<!--main content start-->
<section id="main-content">
<section class="wrapper">


 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/dashboard2" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">


                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">Start Date</label>
                                    <select name="day" id="day" class="form-control">
                                        <?php for($days=1;$days <= 31; $days++) { ?>
                                        <option @if($day == $days) selected="" @endif value="{{$days}}">{{$days}}</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">Month</label>
                                    <select name="month" id="month" class="form-control">
                                        <?php for($months=1;$months <= 12; $months++) { ?>
                                        <option @if($month == $months) selected="" @endif value="{{$months}}">{{$months}}</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">Year</label>
                                    <select name="year" id="year" class="form-control">
                                        <?php for($years=date("Y");$years >= 2015; $years--) { ?>
                                        <option @if($year == $years) selected="" @endif value="{{$years}}">{{$years}}</option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">End Date</label>
                                    <select name="day1" id="day1" class="form-control">
                                        <?php for($days=1;$days <= 31; $days++) { ?>
                                        <option @if($day1 == $days) selected="" @endif value="{{$days}}">{{$days}}</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">Month</label>
                                    <select name="month1" id="month1" class="form-control">
                                        <?php for($months=1;$months <= 12; $months++) { ?>
                                        <option @if($month1 == $months) selected="" @endif value="{{$months}}">{{$months}}</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="exampleInputPassword1">Year</label>
                                    <select name="year1" id="year1" class="form-control">
                                        <?php for($years=date("Y");$years >= 2015; $years--) { ?>
                                        <option @if($year1 == $years) selected="" @endif value="{{$years}}">{{$years}}</option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <input type="hidden" name="fromdate" id="fromdate" value="{{$fromdate}}">
                                <input type="hidden" name="todate" id="todate" value="{{$todate1}}">

                                <div class="form-group col-md-4 pull-right">
                                    <label for=""></label><br>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </div>

                        </section>
                        </form>
                    </div>
            </div>

<div class="row"><div class="col-md-12">
<?php
    if(empty($campaignids)){
  foreach ($list_idss as $lids) { 
  $chartid = $lids->list_id; ?>
      <a data-toggle="modal" href="#myModal2" onclick="getbatch('{{$chartid}}');">
        <div class="col-sm-4 panel">
            <canvas id="pie-chart<?php echo $chartid; ?>" width="800" height="450"></canvas>
        </div>
      </a>
    <?php } } 
    else{
    $chartids = explode(",", $listids);
    foreach ($chartids as $chartid) {
    ?>
      <a data-toggle="modal" href="#myModal2" onclick="getbatch('{{$chartid}}');">
        <div class="col-sm-4 panel">
            <canvas id="pie-chart<?php echo $chartid; ?>" width="800" height="450"></canvas>
        </div>
      </a>
    <?php } } ?>

    </div>

</div>

<!-- Modal -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content"style="width: 800px;">
          <form action="{{url('/dashboard_export')}}" method="post">
          {{csrf_field()}}
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><span  id="modal-title">Batch Details </span><button type="submit" class="btn btn-warning btn-xs btn-block"><i class="fa fa-upload"></i> Export</button></h4>
                <input type="hidden" name="fromdate" value="{{$fromdate}}">
                <input type="hidden" name="todate" value="{{$todate1}}">
                <input type="hidden" name="list_id" id="list_id" value="0">
            </div>
            <div class="modal-body" style="height: 1000px;" id="batchbody">

            </div>
          </form>
        </div>
    </div>
</div>

<!-- modal -->

</section>
</section>
<!--main content end-->
<!--right sidebar start-->
<div class="right-sidebar">
<div class="search-row">
    <input type="text" placeholder="Search" class="form-control">
</div>
<div class="right-stat-bar">
<ul class="right-side-accordion">
<li class="widget-collapsible">
    <a href="{{asset('')}}/bucket/#" class="head widget-head red-bg active clearfix">
        <span class="pull-left">work progress (5)</span>
        <span class="pull-right widget-collapse"><i class="ico-minus"></i></span>
    </a>
    <ul class="widget-container">
        <li>
            <div class="prog-row side-mini-stat clearfix">
                <div class="side-graph-info">
                    <h4>Target sell</h4>
                    <p>
                        25%, Deadline 12 june 13
                    </p>
                </div>
                <div class="side-mini-graph">
                    <div class="target-sell">
                    </div>
                </div>
            </div>
            <div class="prog-row side-mini-stat">
                <div class="side-graph-info">
                    <h4>product delivery</h4>
                    <p>
                        55%, Deadline 12 june 13
                    </p>
                </div>
                <div class="side-mini-graph">
                    <div class="p-delivery">
                        <div class="sparkline" data-type="bar" data-resize="true" data-height="30" data-width="90%" data-bar-color="#39b7ab" data-bar-width="5" data-data="[200,135,667,333,526,996,564,123,890,564,455]">
                        </div>
                    </div>
                </div>
            </div>
            <div class="prog-row side-mini-stat">
                <div class="side-graph-info payment-info">
                    <h4>payment collection</h4>
                    <p>
                        25%, Deadline 12 june 13
                    </p>
                </div>
                <div class="side-mini-graph">
                    <div class="p-collection">
                        <span class="pc-epie-chart" data-percent="45">
                        <span class="percent"></span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="prog-row side-mini-stat">
                <div class="side-graph-info">
                    <h4>delivery pending</h4>
                    <p>
                        44%, Deadline 12 june 13
                    </p>
                </div>
                <div class="side-mini-graph">
                    <div class="d-pending">
                    </div>
                </div>
            </div>
            <div class="prog-row side-mini-stat">
                <div class="col-md-12">
                    <h4>total progress</h4>
                    <p>
                        50%, Deadline 12 june 13
                    </p>
                    <div class="progress progress-xs mtop10">
                        <div style="width: 50%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-info">
                            <span class="sr-only">50% Complete</span>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    </ul>
</li>
<li class="widget-collapsible">
    <a href="{{asset('')}}/bucket/#" class="head widget-head terques-bg active clearfix">
        <span class="pull-left">contact online (5)</span>
        <span class="pull-right widget-collapse"><i class="ico-minus"></i></span>
    </a>
    <ul class="widget-container">
        <li>
            <div class="prog-row">
                <div class="user-thumb">
                    <a href="{{asset('')}}/bucket/#"><img src="{{asset('')}}/bucket/images/avatar1_small.jpg" alt=""></a>
                </div>
                <div class="user-details">
                    <h4><a href="{{asset('')}}/bucket/#">Jonathan Smith</a></h4>
                    <p>
                        Work for fun
                    </p>
                </div>
                <div class="user-status text-danger">
                    <i class="fa fa-comments-o"></i>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb">
                    <a href="{{asset('')}}/bucket/#"><img src="{{asset('')}}/bucket/images/avatar1.jpg" alt=""></a>
                </div>
                <div class="user-details">
                    <h4><a href="{{asset('')}}/bucket/#">Anjelina Joe</a></h4>
                    <p>
                        Available
                    </p>
                </div>
                <div class="user-status text-success">
                    <i class="fa fa-comments-o"></i>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb">
                    <a href="{{asset('')}}/bucket/#"><img src="{{asset('')}}/bucket/images/chat-avatar2.jpg" alt=""></a>
                </div>
                <div class="user-details">
                    <h4><a href="{{asset('')}}/bucket/#">John Doe</a></h4>
                    <p>
                        Away from Desk
                    </p>
                </div>
                <div class="user-status text-warning">
                    <i class="fa fa-comments-o"></i>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb">
                    <a href="{{asset('')}}/bucket/#"><img src="{{asset('')}}/bucket/images/avatar1_small.jpg" alt=""></a>
                </div>
                <div class="user-details">
                    <h4><a href="{{asset('')}}/bucket/#">Mark Henry</a></h4>
                    <p>
                        working
                    </p>
                </div>
                <div class="user-status text-info">
                    <i class="fa fa-comments-o"></i>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb">
                    <a href="{{asset('')}}/bucket/#"><img src="{{asset('')}}/bucket/images/avatar1.jpg" alt=""></a>
                </div>
                <div class="user-details">
                    <h4><a href="{{asset('')}}/bucket/#">Shila Jones</a></h4>
                    <p>
                        Work for fun
                    </p>
                </div>
                <div class="user-status text-danger">
                    <i class="fa fa-comments-o"></i>
                </div>
            </div>
            <p class="text-center">
                <a href="{{asset('')}}/bucket/#" class="view-btn">View all Contacts</a>
            </p>
        </li>
    </ul>
</li>
<li class="widget-collapsible">
    <a href="{{asset('')}}/bucket/#" class="head widget-head purple-bg active">
        <span class="pull-left"> recent activity (3)</span>
        <span class="pull-right widget-collapse"><i class="ico-minus"></i></span>
    </a>
    <ul class="widget-container">
        <li>
            <div class="prog-row">
                <div class="user-thumb rsn-activity">
                    <i class="fa fa-clock-o"></i>
                </div>
                <div class="rsn-details ">
                    <p class="text-muted">
                        just now
                    </p>
                    <p>
                        <a href="{{asset('')}}/bucket/#">Jim Doe </a>Purchased new equipments for zonal office setup
                    </p>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb rsn-activity">
                    <i class="fa fa-clock-o"></i>
                </div>
                <div class="rsn-details ">
                    <p class="text-muted">
                        2 min ago
                    </p>
                    <p>
                        <a href="{{asset('')}}/bucket/#">Jane Doe </a>Purchased new equipments for zonal office setup
                    </p>
                </div>
            </div>
            <div class="prog-row">
                <div class="user-thumb rsn-activity">
                    <i class="fa fa-clock-o"></i>
                </div>
                <div class="rsn-details ">
                    <p class="text-muted">
                        1 day ago
                    </p>
                    <p>
                        <a href="{{asset('')}}/bucket/#">Jim Doe </a>Purchased new equipments for zonal office setup
                    </p>
                </div>
            </div>
        </li>
    </ul>
</li>
<li class="widget-collapsible">
    <a href="{{asset('')}}/bucket/#" class="head widget-head yellow-bg active">
        <span class="pull-left"> shipment status</span>
        <span class="pull-right widget-collapse"><i class="ico-minus"></i></span>
    </a>
    <ul class="widget-container">
        <li>
            <div class="col-md-12">
                <div class="prog-row">
                    <p>
                        Full sleeve baby wear (SL: 17665)
                    </p>
                    <div class="progress progress-xs mtop10">
                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                            <span class="sr-only">40% Complete</span>
                        </div>
                    </div>
                </div>
                <div class="prog-row">
                    <p>
                        Full sleeve baby wear (SL: 17665)
                    </p>
                    <div class="progress progress-xs mtop10">
                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                            <span class="sr-only">70% Completed</span>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    </ul>
</li>
</ul>

</div>

</div>
<!--right sidebar end-->
</section>
<!-- Placed js at the end of the document so the pages load faster -->
<!--Core js-->
<script src="{{asset('/bucket')}}/js/jquery.js"></script>
<script src="{{asset('/bucket')}}/js/jquery-ui/jquery-ui-1.10.1.custom.min.js"></script>
<script src="{{asset('/bucket')}}/bs3/js/bootstrap.min.js"></script>
<script src="{{asset('/bucket')}}/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="{{asset('/bucket')}}/js/jquery.scrollTo.min.js"></script>
<script src="{{asset('/bucket')}}/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js"></script>
<script src="{{asset('/bucket')}}/js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="{{asset('/bucket')}}/js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="{{asset('/bucket')}}/js/skycons/skycons.js"></script>
<script src="{{asset('/bucket')}}/js/jquery.scrollTo/jquery.scrollTo.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="{{asset('/bucket')}}/js/calendar/clndr.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js"></script>
<script src="{{asset('/bucket')}}/js/calendar/moment-2.2.1.js"></script>
<script src="{{asset('/bucket')}}/js/evnt.calendar.init.js"></script>
<script src="{{asset('/bucket')}}/js/jvector-map/jquery-jvectormap-1.2.2.min.js"></script>
<script src="{{asset('/bucket')}}/js/jvector-map/jquery-jvectormap-us-lcc-en.js"></script>
<script src="{{asset('/bucket')}}/js/gauge/gauge.js"></script>

<!-- <script src="{{asset('/bucket')}}/js/dashboard.js"></script> -->
<script src="{{asset('/bucket')}}/js/jquery.customSelect.min.js" ></script>
<!--common script init for all pages-->
<script src="{{asset('/bucket')}}/js/scripts.js"></script>


<script src="{{asset('/bucket')}}/js/Chart.min.js"></script>
<script src="{{asset('/bucket')}}/js/utils.js"></script> 

<script type="text/javascript">

  function getbatch(idval){
    //$("#agentsHTML").html("");
    $("#list_id").val(idval);
    var fromdate = $("#fromdate").val(); 
    var todate = $("#todate").val(); 
          var dataval = '';
          var datalist = '';
    $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getbatch')}}",
    data: {fromdate: fromdate,todate: todate,idval: idval}, 
    dataType:'JSON', 
    success: function(data){
         //alert(data.batch1 +'__'+ data.batch2+'__'+data.batch3+'__'+data.batch4);
        // alert(data.list1 +'__'+ data.list2+'__'+data.list3+'__'+data.list4);
        $('#batchbody').html(data.divhtml);
        $('#modal-title').html(data.listname);
        var batcount = data.batcount;
        for (var i = 1; i <= batcount; i++) {
          if(i == '1'){
          dataval = data.batch1;
          datalist = data.list1;
          }
          if(i == '2'){
          dataval = data.batch2;
          datalist = data.list2;
          }
          if(i == '3'){
          dataval = data.batch3;
          datalist = data.list3;
          }
          if(i == '4'){
          dataval = data.batch4;
          datalist = data.list4;
          }
          var fields = dataval.split(',');
          var data1 = fields[0];
          var data2 = fields[1];
          var data3 = fields[2];
          var data4 = fields[3];
          var data5 = fields[4];
          //alert(dataval);
          new Chart(document.getElementById("pie-chartbatch"+i), {
              type: 'pie',
              data: {
                labels: ["Dialable", "Answer", "Rejected", "No Answer", "Drop"],
                datasets: [{
                  label: "Calls",
                  backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
                  data: [data1,data2,data3,data4,data5]
                }]
              },
              options: {
                title: {
                  display: true,
                  text: datalist
                }
              }
          });
        }

        },error:function(){ 
            //alert("error!!!!");
        }
  });


  }



    var timeleft = 10; 
   var downloadTimer = setInterval(function(){
    timeleft--;
    document.getElementById("countdowntimer").textContent = timeleft;
    if(timeleft <= 0)
        clearInterval(downloadTimer);
    },1000);

<?php
if(empty($campaignids)){
foreach ($list_idss as $lids) { ?>
<?php 
$chartid = $lids->list_id;
 $listnames = App\VicidialLists::select('list_name')->where('list_id',$chartid)->get();
    $listname =  '';
    if(count($listnames) > 0){
       $listname =  $listnames[0]->list_name;
    }

    $dial_lists_new = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','NEW')->count();
    $dial_lists_ans = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','answer')->count();
    $dial_lists_b = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','B')->count();
    $dial_lists_na = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','NA')->count();
    $dial_lists_drop = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','DROP')->count();

    $dial_lists_total = $dial_lists_new+$dial_lists_ans+$dial_lists_b+$dial_lists_na+$dial_lists_drop;

    $dial_lists_newp = ceil(App\Average::MathPER($dial_lists_new,$dial_lists_total));
    $dial_lists_ansp = ceil(App\Average::MathPER($dial_lists_ans,$dial_lists_total));
    $dial_lists_bp = ceil(App\Average::MathPER($dial_lists_b,$dial_lists_total));
    $dial_lists_nap = ceil(App\Average::MathPER($dial_lists_na,$dial_lists_total));
    $dial_lists_dropp = ceil(App\Average::MathPER($dial_lists_drop,$dial_lists_total));
?>
    new Chart(document.getElementById("pie-chart<?php echo $chartid; ?>"), {
    type: 'pie',
    data: {
      labels: ["Dialable (<?php echo $dial_lists_newp; ?>%) - <?php echo $dial_lists_new; ?>", "Answer (<?php echo $dial_lists_ansp; ?>%) - <?php echo $dial_lists_ans; ?>", "Rejected (<?php echo $dial_lists_bp; ?>%) - <?php echo $dial_lists_b; ?>", "No Answer (<?php echo $dial_lists_nap; ?>%) - <?php echo $dial_lists_na; ?>", "Drop (<?php echo $dial_lists_dropp; ?>%) - <?php echo $dial_lists_drop; ?>"],
      datasets: [{
        label: "Calls",
        backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
        data: [<?php echo $dial_lists_new.','.$dial_lists_ans.','.$dial_lists_b.','.$dial_lists_na.','.$dial_lists_drop; ?>]
      }]
    },
    options: {
      title: {
        display: true,
        text: '<?php echo $listname; ?>'
      }
    }
});
<?php  } 
}
else{
$chartids = explode(",", $listids);
foreach ($chartids as $chartid) {
 $listnames = App\VicidialLists::select('list_name')->where('list_id',$chartid)->get();
    $listname =  '';
    if(count($listnames) > 0){
       $listname =  $listnames[0]->list_name;
    }

    $dial_lists_new = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','NEW')->count();
    $dial_lists_ans = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','answer')->count();
    $dial_lists_b = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','B')->count();
    $dial_lists_na = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','NA')->count();
    $dial_lists_drop = App\VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$chartid)->where('status','DROP')->count();

    $dial_lists_total = $dial_lists_new+$dial_lists_ans+$dial_lists_b+$dial_lists_na+$dial_lists_drop;

    $dial_lists_newp = ceil(App\Average::MathPER($dial_lists_new,$dial_lists_total));
    $dial_lists_ansp = ceil(App\Average::MathPER($dial_lists_ans,$dial_lists_total));
    $dial_lists_bp = ceil(App\Average::MathPER($dial_lists_b,$dial_lists_total));
    $dial_lists_nap = ceil(App\Average::MathPER($dial_lists_na,$dial_lists_total));
    $dial_lists_dropp = ceil(App\Average::MathPER($dial_lists_drop,$dial_lists_total));
?>
    new Chart(document.getElementById("pie-chart<?php echo $chartid; ?>"), {
    type: 'pie',
    data: {
      labels: ["Dialable (<?php echo $dial_lists_newp; ?>%) - <?php echo $dial_lists_new; ?>", "Answer (<?php echo $dial_lists_ansp; ?>%) - <?php echo $dial_lists_ans; ?>", "Rejected (<?php echo $dial_lists_bp; ?>%) - <?php echo $dial_lists_b; ?>", "No Answer (<?php echo $dial_lists_nap; ?>%) - <?php echo $dial_lists_na; ?>", "Drop (<?php echo $dial_lists_dropp; ?>%) - <?php echo $dial_lists_drop; ?>"],
      datasets: [{
        label: "Calls",
        backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
        data: [<?php echo $dial_lists_new.','.$dial_lists_ans.','.$dial_lists_b.','.$dial_lists_na.','.$dial_lists_drop; ?>]
      }]
    },
    options: {
      title: {
        display: true,
        text: '<?php echo $listname; ?>'
      }
    }
});
<?php  } 
} ?>


  </script>
</body>
</html>