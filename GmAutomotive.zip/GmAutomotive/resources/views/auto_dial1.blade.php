@extends('layouts.master')
@section('title', 'Upload Auto Dial by API')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form  action="{{url('/auto/upload')}}" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Upload Auto Dial
                        </header>
                        @if (session('alert'))
                            <div class="alert alert-success fade in">
                                <button data-dismiss="alert" class="close close-sm" type="button">
                                    <i class="fa fa-times"></i>
                                </button>
                                 {!! session('alert') !!}.
                            </div>
						            @endif
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Campaign ID</label>
                                    <select class="form-control" name="campaignid" onChange="getlist(this);">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $campaign)
                                        <option value="{{$campaign->campaign_id}}">{{$campaign->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">List ID</label>

                                    <select class="form-control" name="listid" id="listid" onChange="getlistid(this);">
                                        <option value="">Select</option>
                                        @foreach($lists as $list)
                                        <option value="{{$list->list_id}}">{{$list->list_name}}</option>     
                                        @endforeach
                                    </select>
                                </div>
                                <!-- <input type="hidden" name="listid" id="listid" value="0"> -->
                                <input type="hidden" name="getdetails" id="getdetails" value="">
                                <input type="hidden" name="prevlistid" id="prevlistid" value="1">
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">CLN Code</label>
                                    <input type="text" name="clnnumber" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">BatchNo.</label>
                                    <input type="text" name="batchno" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Choose File</label>
                                    <input type="file" name="import_file" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInputEmail1">Batch Target</label>
                                    <input type="text" name="batchtarget" class="form-control">
                                </div>
                                <div class="form-group col-md-4"><br>
                                <button type="submit" class="btn btn-success btn-block" id="submitbtn">Upload</button>
                                </div><br>
                                <div class="alert alert-danger alert-block fade in col-md-12" id="targethtml" style="display: none;">
                                </div>
                    </section>
                            </form>

                        </div>
            </div>
 <style type="text/css">
      option{

     padding:5px 0;
   }
 </style> 
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getlistid(val) {

       var listid = val.value;

        getlisttarget(listid);

       //alert(listid);
       var apptab = 0;
       var urlcode = '';
       document.getElementById("getdetails").value = "";
       if(listid == '1001' || listid == '2000' || listid == '1010'){
            apptab = 1;
            urlcode = "SER";
       }
       else if(listid == '1002'){
            apptab = 1;
            urlcode = "APP";
       }
       else if(listid == '1008' || listid == '5008' || listid == '5009'){
            apptab = 1;
            urlcode = "AAP";
       }
       else if(listid == '1004' || listid == '2003' || listid == '2004'){
            apptab = 1;
            urlcode = "GSP";
       }
       else if(listid >= '3001' && listid <= '3017'){
            apptab = 1;
            urlcode = "GSP";
       }
       else if(listid >= '4000' && listid <= '4008'){
            apptab = 1;
            urlcode = "GSP";
       }
       else if(listid >= '5000' && listid <= '5007'){
            apptab = 1;
            urlcode = "BTB";
       }
       else if(listid == '999' || listid == '2002'){
            apptab = 1;
            urlcode = "FSR";
       }
       else{
            document.getElementById("getdetails").value = '';
            $('#submitbtn').attr("disabled", false);
       }
       if(apptab == '1'){
            callAPI(urlcode);      
       }

    }

function callAPI(urlcode){
            $('#submitbtn').attr("disabled", true);
 //alert(urlcode);
 var apivar = "https://chevrolet-autoline-prod-api.alghanim-prod-ase.p.azurewebsites.net/contact/getdetails?script="+urlcode;
  $.ajax({
                 url:apivar,
                 type:'GET',
                           dataType: 'json',
                           contentType: "application/json; charset=utf-8",
                           mimeType: "multipart/form-data",
                 beforeSend : function() {
                  $('body').css('cursor', 'progress');
                      //alert(person2);
                 },
                 success : function(data) {
                       // alert(data);
                        var details = JSON.stringify(data);
                        //alert(details);
                        document.getElementById("getdetails").value = details;
                         $('#submitbtn').attr("disabled", false);

                       //$('#success-alert').modal('toggle');

                  $('body').css('cursor', 'default');
                 },
                 error:function(res){
                        //alert("Bad thing happend! " + res.statusText);
                    $('#submitbtn').attr("disabled", false);
                        
                  },
                 async : true
      });
}



function getlist(id) {
  var campaign = id.value;
  //alert(campaign);
       document.getElementById("getdetails").value = "";
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlistids')}}",
    data: {campaign:campaign}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        $("#listid").html("");
        $("#listid").html(response.divhtml);
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }

function getlisttarget(listid) {
  //alert(listid);
  $("#targethtml").html("");
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getlisttarget')}}",
    data: {listid:listid}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.divhtml);
        if (response.divhtml != "") {
          $("#targethtml").show();
          $("#targethtml").html(response.divhtml);
        }
        else{
          $("#targethtml").hide();         
        }
      
    },error:function(){ 
            //alert("error!!!!");
        }
  });
  }
</script>


@stop
