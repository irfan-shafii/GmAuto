@extends('layouts.master')
@section('title', 'New Vehicle')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form action="{{url('/')}}/vehicle/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Vehicle Details
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Mobile Number</label>
                                    <input size="16" type="text" value="" name="mobile" class="form_date form-control">
                                    <!-- <select id="e1" class="populate " style="width: 300px">
                                        <option value="">Select</option>
                                @foreach($accounts as $account)
                                        <option value="{{$account->mobile_number}}">{{$account->mobile_number}}</option>
                                @endforeach
                                    </select> -->
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Type</label>
                                    <select class="form-control" name="type" style="width: 300px">
                                        <option value="">Select</option>
                                        <option value="SUV">SUV</option>
                                        <option value="MPV">MPV</option>
                                        <option value="Crossover">Crossover</option>
                                        <option value="Hatchback">Hatchback</option>
                                        <option value="Sedan">Sedan</option>
                                        <option value="Coupe">Coupe</option>
                                        <option value=" Convertible"> Convertible</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Brand</label>
                                    <select class="form-control" name="brand" style="width: 300px" onChange="getmodel(this);">
                                        <option value="">Select</option>
                                        <option value="Honda">Honda</option>
                                        <option value="Chevrolet">Chevrolet</option>
                                        <option value="Cadillac">Cadillac</option>
                                        <option value="Ford">Ford</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Model</label>
                                    <div id="vehmodel"></div>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Plate No</label>
                                    <input type="text" class="form-control" name="plateno" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Chasis No</label>
                                    <input type="text" class="form-control" name="chasisno" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Model Year</label>
                                    <input type="text" class="form-control" name="modelyear" id="message">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Dealer Name</label>
                                    <input size="16" type="text" value="" name="dealer" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Name Of Town</label>
                                    <input size="16" type="text" value="" name="town" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Date Of Sale</label>
                                    <input size="16" type="text" value="" name="dosale" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Warranty Years</label>
                                    <input size="16" type="text" value="" name="warranty" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Status</label>
                                    <select class="form-control" name="status" style="width: 300px">
                                        <option value="">Select</option>
                                        <option value="Ready To Delivery">Ready To Delivery</option>
                                        <option value="Waiting For Approval">Waiting For Approval</option>
                                        <option value="Parts Not Available">Parts Not Available</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                <button type="submit" class="form-control btn btn-success btn-block">Submit</button>
                                <a href="javascript: history.go(-1)" class="form-control btn btn-danger btn-block">Close</a>
                                </div>
                            </form>

                        </div>
                    </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getmodel(id) {
        //alert(id.value);
            $("#vehmodel").html("");
        var brand = id.value;
        var Honda = ['accord','city'];
        var Chevrolet = ['tahoe','impala'];
        var Cadillac = ['cts','sts'];
        var Ford = ['taurus','edge'];
        var divHTML = "";
        divHTML += "<select class='form-control' name='model'>";
        if(brand == 'Honda'){            
            divHTML += "<option value='"+Honda[0]+"'>"+Honda[0]+"</option>";
            divHTML += "<option value='"+Honda[1]+"'>"+Honda[1]+"</option>";
        }
        else if(brand == 'Chevrolet'){            
            divHTML += "<option value='"+Chevrolet[0]+"'>"+Chevrolet[0]+"</option>";
            divHTML += "<option value='"+Chevrolet[1]+"'>"+Chevrolet[1]+"</option>";
        }
        else if(brand == 'Cadillac'){            
            divHTML += "<option value='"+Cadillac[0]+"'>"+Cadillac[0]+"</option>";
            divHTML += "<option value='"+Cadillac[1]+"'>"+Cadillac[1]+"</option>";
        }
        else if(brand == 'Ford'){            
            divHTML += "<option value='"+Ford[0]+"'>"+Ford[0]+"</option>";
            divHTML += "<option value='"+Ford[1]+"'>"+Ford[1]+"</option>";
        }
            divHTML += "</select>";
        //alert(divHTML);
            $("#vehmodel").html(divHTML);

    }
</script>

@stop
