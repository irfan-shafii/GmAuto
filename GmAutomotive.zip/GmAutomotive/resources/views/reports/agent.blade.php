@extends('layouts.master')
@section('title', 'Agent Performance Details')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 

           <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/report')}}/agent/performance" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Campaigns :</label>
			                      <select class="form-control" name="campaign">
			                          <option value="">Select All</option>
			                          @foreach($campaigns as $camp)
			                          <option value="{{$camp->campaign_id}}" @if($camp->campaign_id == $campaign) selected="" @endif>{{$camp->campaign_name}}</option>
			                          @endforeach
			                      </select>
                                </div>

                                <div class="form-group col-md-4">
			                    <label>Inbound Groups</label>
			                      <select class="select2 form-control" name="usergroup">
			                          <option value="">Select All</option>
			                          @foreach($usergroups as $group)
			                          <option value="{{$group->user_group}}" @if($group->user_group == $usergroup) selected="" @endif>{{$group->group_name}}</option>
			                          @endforeach
			                      </select>
                                </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </section>

                        </form>
                    </div>
            </div>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Agent Performance Details <a href="#" class="pull-right btn btn-space btn-xs btn-warning" onclick="printpage();">Export / Print</a></strong><span class="pull-right"> Total <strong></strong> Records </span>
                    </header>
                    <div class="panel-body" id="tableDiv">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table" style="background:white;">
                    <thead>
                    <tr>
                        
                    <th>Agent Name</th>
                    <th>User ID</th>
                    <th>User Group</th>
                    <th>Calls</th>
                    <th>Inbounds</th>
                    <th>Outbounds</th>
                    <th>Missed</th>
                    <th>Time</th>
                    <th>Pause</th>
                    <th>Pause Avg</th>
                    <th>Wait</th>
                    <th>Wait Avg</th>
                    <th>Talk</th>
                    <th>Talk Avg</th>
                    <th>Dispo</th>
                    <th>Dispo Avg</th>
                    <th>Dead</th>
                    <th>Dead Avg</th>
                    <th>Answer</th>
                    </tr>
                    </thead>
                    <tbody>
                      {!!$divhtml!!}
                    </tbody>
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Pause Code Break Down</strong><span class="pull-right">Total <strong></strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                    <th>Agent Name</th>
                    <th>User ID</th>
                    <th>Total</th>
                    <th>Total Paused</th>
                    <th>Total Non Paused</th>
                    </tr>
                    </thead>
                    <tbody>

                      {!!$divhtml1!!}
                    </tbody>
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
       
@stop
@section('ScriptPage')
<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }
</script>
@stop
