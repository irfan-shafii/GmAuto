@extends('layouts.master')
@section('title', 'Outbound Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/record/outbound" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">From Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($fromdate))}}" name="fromdate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">To Date</label>
                                    <input size="16" type="text" value="{{date('m-d-Y',strtotime($todate))}}" name="todate" class="form-control form-control-inline input-medium default-date-picker" autocomplete="off">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input size="16" type="text" value="{{$phone}}" name="phone" class="form-control">
                                </div>

                            <div class="form-group pull-right col-md-6">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>

<style type="text/css">

tr.ex2:hover, a.ex2:active {background-color:#d0f7a9 ! important;font-size: 125%;}
.member tr.selected {background-color:#d0f7a9 ! important;}

</style>

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Outbound Report</strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>Phone</th>
                    <th>Campaign</th>
                    <th>Call Date</th>
                    <th>Status</th>
                    <th>User</th>
                    <th>List ID</th>
                    <th>Length</th>
                    <th>Dial</th>
                    <th>Recordings</th>
                    </tr>
                    </thead>
                    <tbody class="member">
                  @if(count($dial_logs) > 0)
                  @foreach($dial_logs as $log)
                  <?php 
                $records = App\VicidialRecord::where('lead_id',$log->lead_id)->where('vicidial_id',$log->uniqueid)->where('user',$log->user)->get();
                if(count($records) > 0){
                    $wav_url = '/RECORDINGS/MP3/'.$records[0]->filename.'-all.mp3';
                }
                else{
                    $wav_url = '';
                }
                ?>
                    <tr class="ex2">
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->phone_number}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->campaign_id}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->call_date}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->status}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->user}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->list_id}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->length_in_sec}}</td>
                    <td style="cursor: pointer;" onclick="playwav('{{$log->uniqueid}}');">{{$log->alt_dial}}</td>
                    <td>
                        <a href="{{$wav_url}}" download="" class="btn btn-round btn-danger btn-xs">Download</a>
                        <input type="hidden" name="audio" id="audio{{$log->uniqueid}}" value="{{$wav_url}}">
                    </td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
                <input type="hidden" name="prevaudio" id="prevaudio" value="0">
            </div>
        </div>



        <div class="row" id="audioform" style="display: none;">
            <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-body">
                            <div id="waveform"></div>

                            <div class="col-md-4"></div>

                            <div class="form-group col-md-4">
                            <a style="cursor: pointer;" class="btn btn-primary" onclick="playwavform();"><i class="fa fa-play"></i></a>
                            <a style="cursor: pointer;" class="btn btn-primary" onclick="pausewav();"><i class="fa fa-pause"></i></a>
                            <a style="cursor: pointer;" class="btn btn-primary" onclick="stopwav();"><i class="fa fa-stop"></i></a>
                            <a style="cursor: pointer;" class="btn btn-primary" onclick="backwardwav();"><i class="fa fa-backward"></i></a>
                            <a style="cursor: pointer;" class="btn btn-primary" onclick="forwardwav();"><i class="fa fa-forward"></i></a>
                        </div>
                    </div>
                </section>
            </div>
        </div>
@stop
@section('ScriptPage')
<script src="https://unpkg.com/wavesurfer.js"></script>
<script type="text/javascript">

var wavesurfer = WaveSurfer.create({
    container: '#waveform',
    waveColor: 'violet',
    progressColor: 'purple'
});
//wavesurfer.load('/RECORDINGS/MP3/20200415-212530_94069744-all.mp3');


function playwavform() {
    wavesurfer.play();
}
function pausewav() {
    wavesurfer.pause();
}
function stopwav() {
    wavesurfer.stop();
}
function backwardwav() {
    wavesurfer.skipBackward();
}
function forwardwav() {
    wavesurfer.skipForward();
}

$("tr").click(function() {
  $(this).parent().children().removeClass("selected");
    $(this).addClass("selected");
//alert("hi");
});

function playwav(id) {
    $("#audioform").show(); 
  // $(".rclist").removeClass("selected");
  // $("#rclist"+id).addClass("selected");
    //$.scrollTo($('#audioform'), 1000);
    wavesurfer.stop();
    wavesurfer.empty();
    //var prev = $("#prevaudio").val();
    //alert("hi"+id);
    var audio = document.getElementById("audio"+id).value;
    //alert(audio);
    wavesurfer.load(audio);
    //wavesurfer.play();
        $('html, body').animate({
            scrollTop: $('#audioform').offset().top
        }, 'slow');
}

// function stopwav(id) {
//     //alert("stop");
//     var prev = $("#prevaudio").val();
//     document.getElementById("my_audio"+prev).pause();
// }
</script>

@stop
