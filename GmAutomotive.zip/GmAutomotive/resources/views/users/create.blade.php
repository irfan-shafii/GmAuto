@extends('layouts.master')
@section('title', 'User Create')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/users/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter Your Name">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">User ID</label>
                                    <input type="text" name="email" class="form-control" placeholder="Enter Your User ID">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Enter Your Password">
                                </div>
                                <input type="hidden" name="user_type" value="agent">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Campaigns</label>
                                    <select multiple name="campaigns[]" id="e9" style="width:300px" class="populate">
                                        @foreach($campaigns as $list)
                                        <option value="{{$list->campaign_id}}">{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">User Groups</label>
                                    <select multiple name="groups[]" id="e1" style="width:300px" class="populate">
                                        @foreach($usergroups as $groups)
                                        <option value="{{$groups->user_group}}">{{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group pull-right col-md-4">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Submit</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop
