@extends('layouts.master')
@section('title', 'User List')
@section('breadCrumbs')
        
@stop

@section('pageBody')


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>User Details <a href="{{url('/users')}}/create" class="pull-right btn btn-space btn-xs btn-warning">Create</a></strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>User ID</th>
                        <th>User Type</th>
                        <th>Campaigns</th>
                        <th>User Groups</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $user)
                    <tr class="gradeX">
                        <td>{{$user->id_user}}</td>
                        <td>{{$user->name}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->user_type}}</td>
                        <td>
                        <?php $camps = explode(",", $user->campaignid); 
                        if (!empty($camps)) {
                        foreach($camps as $camp){
                            echo $camp.'<br>';
                        }
                        }
                        ?></td>
                        <td>
                        <?php $ucamps = explode(",", $user->usergroups); 
                        if (!empty($ucamps)) {
                        foreach($ucamps as $ucamp){
                            echo $ucamp.'<br>';
                        }
                        }
                        ?></td>
                        <td>
                        <a href="{{url('/users')}}/edit/{{$user->id_user}}" class="btn btn-space btn-xs btn-info" >Edit</a>
                        <a class="btn btn-space btn-xs btn-danger" onclick="delcustomer('{{$user->id_user}}');">Delete</a>
                        </td>
                        
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    <ul class="pagination pagination-sm pull-right">
                        {!! $users->render() !!}
                    </ul>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }

  function delcustomer(id) {
    var chk = confirm("Are you sure! you want to delete this User?");
    if(chk) {
        window.location = "{{ url('/users') }}/delete/"+id;
    }
  }
</script>

@stop
