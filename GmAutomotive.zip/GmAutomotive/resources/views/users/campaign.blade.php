@extends('layouts.master')
@section('title', 'User Campaign List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/users/campaignstore" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <input type="hidden" name="user_type" value="agent">
                                <div class="form-group col-md-4">
                                    <label for="exampleI">Campaigns</label>
                                    <select name="campaigns" id="campaigns" class="form-control" required="">
                                        <option value="">Select</option>
                                        @foreach($campaigns as $list)
                                        <option value="{{$list->campaign_id}}">{{$list->campaign_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleI">In Groups</label>
                                    <select multiple name="groups[]" id="e1" style="width:300px" class="populate">
                                        @foreach($ingroups as $groups)
                                        <option value="{{$groups->group_id}}">{{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group pull-right col-md-4">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Submit</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>User Campaign Details </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Campaign</th>
                        <th>In Groups</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($user_campaigns as $user)
                    <tr class="gradeX">
                        <td>{{$user->id}}</td>
                        <td>{{$user->campaigns}}</td>
                        <td>{{$user->ingroups}}</td>
                        
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

@stop
