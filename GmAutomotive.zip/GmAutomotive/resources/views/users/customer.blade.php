@extends('layouts.master')
@section('title', 'Customer List')
@section('breadCrumbs')
        
@stop

@section('pageBody')


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Customer Details </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table1">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Civil Id</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Campaign</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $user)
                    <tr class="gradeX">
                        <td>{{$user->id_account}}</td>
                        <td>{{$user->first_name}} {{$user->last_name}}</td>
                        <td>{{$user->mobile_number}}</td>
                        <td>{{$user->civil_id}}</td>
                        <td>{{$user->gender}}</td>
                        <td>{{$user->address}}</td>
                        <td>{{$user->campaign_id}}</td>
                        
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    <ul class="pagination pagination-sm pull-right">
                        {!! $users->render() !!}
                    </ul>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
  function printpage() {


     var tableDiv = document.getElementById("dynamic-table").innerHTML;

        printContents = '';
        printContents += '<table style="border: 1px solid black;border-collapse: collapse;">';
        printContents += tableDiv;
        printContents += '</table>';
    //alert(printContents);
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
  }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop
