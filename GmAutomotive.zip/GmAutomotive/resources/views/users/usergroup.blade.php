@extends('layouts.master')
@section('title', 'Users Usergroup List')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/users/groupstore" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-5">
                                    <label for="exampleI">User Groups</label>
                                    <select name="groups" id="groups" class="form-control" onchange="getusergroup(this.value);">
                                        <?php $all = "---ALL---"; ?>
                                        <option value="">Select</option>
                                        <option value="---ALL---" @if($group == $all) selected="" @endif>Select All</option>
                                        @foreach($usergroups as $groups)
                                        <option value="{{$groups->user_group}}" @if($groups->user_group == $group) selected="" @endif>{{$groups->user_group}} - {{$groups->group_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-5">
                                    <label for="exampleI">Users</label><br>
                                    <div id="usersdiv">
                                    <select name="users[]" id="e9" class="populate" required="" multiple="" style="width: 350px;">
                                        <option value="">Select</option>
                                        @foreach($users as $list)
                                        <?php 
                                        $usersc = App\VicidialUser::select('active','user_group')->where('user_group',$group)->where('user_id',$list->user_id)->where('active','Y')->count();
                                        ?>
                                        <option value="{{$list->user_id}}" @if($usersc > 0) selected="" @endif>{{$list->user}}</option>
                                        @endforeach
                                    </select>
                                    </div>
                                </div>
                            <div class="form-group pull-right col-md-2">
                            <button type="submit" id="submitbtn" class="form-control btn btn-primary btn-block"><i class="fa fa-search"></i> Submit</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>User Usergroup Details </strong>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>User Groups</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $user)
                    <tr class="gradeX">
                        <td>{{$user->user_id}}</td>
                        <td>{{$user->user}}</td>
                        <td>{{$user->user_group}}</td>
                        
                    </tr>
                    @endforeach
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')
<script type="text/javascript">
    
  function getusergroup(group) {
        window.location = "{{ url('/users') }}/groups/"+group;
  }
</script>
@stop
