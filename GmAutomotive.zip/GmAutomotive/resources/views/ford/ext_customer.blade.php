
<!-- <header class="panel-heading wht-bg">
   <h4 class="gen-case"> 
	<a href="#"  class="btn btn-round btn-success">
	Incoming Call
	</a> <a href="#"  class="btn btn-round btn-default">
	Outgoing Call
	</a>
	<span><a href="#"  class="btn btn-info pull-right">
        Campaign Id - Details
    </a></span>
   </h4>
</header> -->
<div class="row">

<div class="col-lg-4">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Customers
</h3>
<ul class="nav nav-pills nav-stacked">
@if(count($mktargt) > 0)
@foreach($mktargt as $acc)
<li class="acclist" id="acclist{{$acc->MAGIC}}"><a class="ex2" href="#" onclick="customerinfo('{{$acc->MAGIC}}');"> <i class="fa fa-user"></i> {{$acc->FIRSTNAM}} {{$acc->SURNAME}}</a></li>
@endforeach
@else
<li>No customer(s) found. Please check your mobile number.</li>
@endif
</ul>
@if(count($mktargt) > 0)
<input type="hidden" id="firstcustomer" value="{{$cusid}}">
@else
<input type="hidden" id="firstcustomer" value="0">
@endif
</div>
</section>
</div>


<div class="col-lg-4">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
vehicles
</h3>

<ul class="nav nav-pills nav-stacked" id="vehicle_list">
</ul>

</div>
</section>
</div>


<div class="col-lg-4">

<section class="panel">
<a href="#"  class="btn btn-info pull-right">
    {{$campaignid}} - {{$ingroup}} - {{$listname}}
</a>
</br></br>
<div class="panel-body">
<div class="input-group m-bot15">
<input type="text" class="form-control" placeholder="Enter Mobile / Register Number" id="phsearch">
<span class="input-group-btn">
<button class="btn btn-success" type="enter" onclick="search();">Search</button>
</span>
</div>
<label><input type="radio" name="searchcon" id="searchcon" value="mobile" checked=""> Mobile</label>
<label><input type="radio" name="searchcon" id="searchcon" value="regno">Register No</label>
</div>
</section>


@if(count($upscales) > 0)
<!--carousel start-->
<section class="panel">
<div id="c-slide" class="carousel slide panel-body" data-ride="carousel">
<ol class="carousel-indicators out">
<?php for($i=0; $i<count($upscales); $i++ ) {
if($i == '0'){
$rowclass = 'active';
}
else{
$rowclass = '';
} ?>
<li class="{{$rowclass}}" data-slide-to="{{$i}}" data-target="#c-slide"></li>
<?php } $rowcount=0; ?>
</ol>
<div class="carousel-inner">
@foreach($upscales as $upscale)
<?php
if($rowcount == '0'){
$rowclass1 = 'active';
}
else{
$rowclass1 = '';
} ?>
<div class="item text-center {{$rowclass1}}">
<h3 style="color: #fa8564;">{{$upscale->topic}}</h3>
<p style="color: #95b75d;">{{$upscale->description}}</p>
</div>
<?php $rowcount++; ?>
@endforeach
</div>
<a data-slide="prev" href="{{asset('/bucket')}}/#c-slide" class="left carousel-control">
<i class="fa fa-angle-left"></i>
</a>
<a data-slide="next" href="{{asset('/bucket')}}/#c-slide" class="right carousel-control">
<i class="fa fa-angle-right"></i>
</a>
</div>
</section>
<!--carousel end-->
@endif
</div>

</div>

<form action="{{url('/ford')}}/enquiry/store" method="post" id="userform">
{{csrf_field()}}

<div class="row">
<div class="col-lg-6">

<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Customer Info</h3>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">First Name</label>
<input type="text" class="form-control" name="fname" id="fname" value="{{$fname}}" placeholder="Enter First Name" required="">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Name</label>
<input type="text" class="form-control" name="lname" id="lname" value="{{$lname}}" placeholder="Enter Last Name">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Mobile Number</label>
<input type="number" class="form-control" name="mobile" id="mobile" value="{{$mobile}}" placeholder="Enter Mobile Number" required="">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Alternative Mobile</label>
<input type="number" class="form-control" name="mobile2" id="mobile2" value="{{$mobile2}}" placeholder="Enter Alternative Mobile">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Civil ID</label>
<input type="text" class="form-control" name="civilid" id="civilid" value="{{$civilid}}" placeholder="Enter Civil ID">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Gender</label>
<select class="form-control" name="gender" id="gender">
<option value="">Select</option>
<option @if($gender == 'Male') selected="" @endif value="Male">Male</option>
<option @if($gender == 'Female') selected="" @endif value="Female">Female</option>
</select>
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Address</label>
<textarea type="text" class="form-control" name="address" id="address" placeholder="Enter Address">{{$address}}</textarea>
</div>
<input type="hidden" name="id_account" id="id_account" value="{{$id_account}}">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<input type="hidden" name="listid" id="listid" value="{{$listid}}">
<input type="hidden" name="campaignid" id="campaignid" value="{{$campaignid}}">
<input type="hidden" name="ingroup" id="ingroup" value="{{$ingroup}}">
<!-- <div class="form-group col-md-6">
<button type="submit" class="btn btn-danger">Save</button>
</div> -->

</div>
</section>
</div>

<div class="col-lg-6">
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Vehicle Info</h3>  
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Info</label>
<input type="text" class="form-control" name="vehicleinfo" id="vehicleinfo" value="" placeholder="Enter Vehicle Info">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Model</label>
<input type="text" class="form-control" name="vehmodel" id="vehmodel" value="" placeholder="Enter Vehicle Model">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Year</label>
<input type="text" class="form-control" name="vehyear" id="vehyear" value="" placeholder="Enter Vehicle Year">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Colour</label>
<input type="text" class="form-control" name="vehcolor" id="vehcolor" value="" placeholder="Enter Vehicle Colour">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Mileage</label>
<input type="text" class="form-control" name="mileage" id="mileage" value="" placeholder="Enter Vehicle Showroom">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Register Number</label>
<input type="text" class="form-control" name="plateno" id="plateno" value="" placeholder="Enter Vehicle Register Number">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Service Date</label>
<input type="text" class="form-control" name="lastservice" id="lastservice" value="" placeholder="Enter Vehicle Service Date">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Service Date</label>
<input type="text" class="form-control" name="nextservice" id="nextservice" value="" placeholder="Enter Vehicle Service Date">
</div>
<input type="hidden" name="vehicle_id" id="vehicle_id" value="0">
<!-- <div class="form-group col-md-6">
<button type="submit" class="btn btn-danger">Save</button>
</div> -->
</div>
</section>

</div>

<!-- <div class="col-lg-4">
<section class="panel">
    <div class="prf-box">
        <h3 class="prf-border-head">QUICK SUMMARY - FOR SELECTED VEHICLE</h3>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Calls - Dialed Today</div>
            <div class="col-md-4 col-xs-4">
                <strong>4</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Call Received Today</div>
            <div class="col-md-4 col-xs-4">
                <strong>2</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Campaign Calls Pending</div>
            <div class="col-md-4 col-xs-4">
                <strong>8</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Missed Calls</div>
            <div class="col-md-4 col-xs-4">
                <strong>1</strong>
            </div>
        </div>
    </div>
</section>

</div> -->
</div>

