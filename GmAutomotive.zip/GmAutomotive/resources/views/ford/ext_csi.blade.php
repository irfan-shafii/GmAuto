
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> CSI Questions
	<a href="#"  class="btn btn-info pull-right">
        {{$campaignid}} - {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>
<div class="row">

<div class="col-lg-9">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Vehicles
</h3>
</header>
<ul class="nav nav-pills" id="vehicle_csi_list">
</ul>

</section>

</div>

<div class="col-lg-3">
<section class="panel">
<div class="panel-body">


      <div class="pull-right mail-src-position">
        <div class="input-append">
            <input type="text" class="form-control " placeholder="Search..">
        </div>
    </div>

</div>
</section>
</div>
</div>

<div class="panel-body">
    <div class="row">
        <div id="questionbox" style="display: none;">
            <div class="alert alert-success alert-block fade in col-md-6">
                <h4 id="questionDIV"> 
                </h4>
            </div>
            <div class="alert alert-success alert-block fade in col-md-6">
                <h4 id="questionDIV1" style="text-align: right;direction: rtl;"> 
                </h4>
            </div>
            <div class="alert alert-danger alert-block fade in col-md-12" style="font-size: 18px;">
                
                <p>
                <div id="answerDIV" style="text-align: center;">
                    
                </div>
                <div id="desDIV"></div>
            </p>
                <input type="button" onclick="getnextquestion()" id="nextbtn" class="btn btn-success pull-right" value="Next Question" disabled="">
            </div>
        </div>
    </div>
                
                <input type="hidden" name="current_time" id="current_time" value="{{date('Y-m-d H:i:s')}}">
                <input type="hidden" id="questionid" name="questionid" value="0">

        <br>

        <!-- <ul id="prev_answers">
        </ul> -->

    <div class="row" style="font-size: 18px;">
        <div class="col-md-6">
        <div class="well" id="prev_answers">
        </div>
        </div>
        <div class="col-md-6">
        <div class="well" id="prev_answers1" style="text-align: right;direction: rtl;">
        </div>
        </div>
    </div>

</div>