
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Contact Information
	<a href="#"  class="btn btn-info pull-right">
        {{$campaignid}} - {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>


<div class="row">

<div class="col-lg-9">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Vehicles
</h3>
</header>
<ul class="nav nav-pills" id="vehicle_contact_list">
</ul>

</section>

</div>

<div class="col-lg-3">
<section class="panel">
<div class="panel-body">


	    <div class="pull-right mail-src-position">
        <div class="input-append">
            <input type="text" class="form-control " placeholder="Search..">
        </div>
    </div>

</div>
</section>
</div>
</div>


<div class="row">
<div class="col-lg-6">
<section class="panel">
<header class="panel-heading">
SEND EMAIl
</header>
<div class="panel-body">

<div class="form-group col-md-10">
<textarea type="text" class="form-control" name="description" id="message" placeholder="Compose Mail"></textarea>
</div>

<div class="form-group col-md-2">
<button type="submit" class="btn btn-danger">Send</button>
</div>
</div>
</section>
</div>



<div class="col-lg-6">


<section class="panel">
<header class="panel-heading">
SEND SMS
</header>
<div class="panel-body">
<div class="form-group col-md-10">
<textarea type="text" class="form-control" name="description" id="message" placeholder="Compose Mail"></textarea>
</div>

<div class="form-group col-md-2">
<button type="submit" class="btn btn-danger">Send</button>
</div>

</div>
</section>
</div>

</div>

