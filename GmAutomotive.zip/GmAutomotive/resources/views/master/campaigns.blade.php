@extends('layouts.master')
@section('title', 'Campaigns')
@section('breadCrumbs')
        
@stop

@section('pageBody')
         <div class="row">
            <div class="col-sm-12">
                

                    <form action="{{url('/master')}}/campaigns/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                           Add Campaigns
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">Name Of Campaign</label>
                                    <input type="text" class="form-control" name="name">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="in_arabic">Description </label>
                                    <textarea type="text" class="form-control" name="description"></textarea>
                                </div>
                                <div class="form-group col-md-3 pull-right">

                                <button type="submit" class="btn btn-success btn-block">SAVE</button>
                                
                                </div>
                    </form>

                        </div>
                    </section>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                       Campaigns Table
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($campaigns as $log)
                    <tr>
                        <td>{{$log->id}}</td>
                        <td>{{$log->name}}</td>
                        <td>{{$log->description}}</td>
                        <td><a href="{{url('/master/campaigns')}}/{{$log->id}}/delete" class="btn btn-danger btn-xs">Delete</a></td>
                    </tr>
                    @endforeach
                    </tbody>
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')


@stop
