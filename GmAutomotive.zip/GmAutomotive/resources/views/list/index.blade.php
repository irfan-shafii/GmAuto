@extends('layouts.master')
@section('title', 'Call Log Search Report')
@section('breadCrumbs')
        
@stop

@section('pageBody')
        <!-- page start--> 
        <div class="row">
            <div class="col-md-12">
                
                    <form action="{{url('/')}}/leads/list" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <div class="panel-body">
                                <div class="form-group col-md-3">
                                    <label for="exampleInputPassword1">Select Date</label>
                                    
                                    <div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="{{date('d-m-Y',strtotime($fromdate))}}"  class="input-append date dpYears" style="width:200px">
                                        <input type="text" value="{{date('d-m-Y',strtotime($fromdate))}}" class="form-control" name="fromdate">
                                              <span class="input-group-btn add-on">
                                                <button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
                                              </span>
                                    </div>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInput">List ID</label>
                                    <select name="list_id" class="form-control">
                                        <option value="">SELECT</option>
                                        @foreach($list_ids as $list)
                                        <option @if($list->list_id == $list_id) selected="" @endif value="{{$list->list_id}}">{{$list->list_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleInput">Batch No.</label>
                                    <select name="batchno" class="form-control">
                                        <option value="">SELECT</option>
                                        @foreach($batches as $batche)
                                        <option @if($batche->batchno == $batchno) selected="" @endif value="{{$batche->batchno}}">{{$batche->batchno}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="exampleI">Status</label>
                                    <select multiple name="status[]" id="e9" style="width:200px" class="populate">
                                        <option @if(strpos($status, 'answer') !== false) selected="" @endif value="answer">Answer</option>
                                        <option @if(strpos($status, 'B') !== false) selected="" @endif value="B">Busy</option>
                                        <option @if(strpos($status, 'NA') !== false) selected="" @endif value="NA">No Answer</option>
                                        <option @if(strpos($status, 'DROP') !== false) selected="" @endif value="DROP">DROP</option>
                                    </select>
                                </div>
                                <input type="hidden" name="resetstatus" id="resetstatus" value="0">
                                <input type="hidden" name="clearstatus" id="clearstatus" value="0">
                                <input type="hidden" name="exportstatus" id="exportstatus" value="0">
                                <div class="col-md-12"></div>
                            <div class="form-group col-md-3">
                            <a href="#" class="btn btn-warning btn-block" onclick="exportexcel();"><i class="fa fa-upload"></i> Export</a>
                            </div>
                            <div class="form-group col-md-3">
                            <a href="#" class="btn btn-default btn-block" onclick="clearbtn();"><i class="fa fa-arrows-alt"></i> Clear List</a>
                            </div>
                            <div class="form-group col-md-3">
                            <a href="#" class="btn btn-danger btn-block" onclick="resetbtn();"><i class="fa fa-retweet"></i> Reset</a>
                            </div>
                            <div class="form-group pull-right col-md-3">
                            <button type="submit" id="submitbtn" class="btn btn-primary btn-block"><i class="fa fa-search"></i> Search</button>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        <strong>Dialer Leads Report</strong><span class="pull-right">Total <strong>{{$dial_lists_count}}</strong> Records</span>
                    </header>
                    <div class="panel-body">
                    <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                    <tr>
                    <th>Lead ID</th>
                    <th>Entry Date</th>
                    <th>Modify Date</th>
                    <th>ListName</th>
                    <th>Status</th>
                    <th>Phone Number</th>
                    <th>User</th>
                    <th>Caller Count</th>
                    <th>Batch No</th>
                    </tr>
                    </thead>
                    <tbody>
                  @if(count($dial_lists) > 0)
                  @foreach($dial_lists as $log)
                  <?php

                    $listnames = App\VicidialLists::select('list_name')->where('list_id',$log->list_id)->get();
                    $listname =  '';
                    if(count($listnames) > 0){
                            $listname =  $listnames[0]->list_name;
                    }
                ?>
                    <tr class="gradeX">
                    <td>{{$log->lead_id}}</td>
                    <td>{{$log->entry_date}}</td>
                    <td>{{$log->modify_date}}</td>
                    <td>{{$listname}}</td>
                    <td>@if($log->status == 'B') Busy @elseif($log->status == 'NA') No Answer @elseif($log->status == 'DA') Pending  @elseif($log->status == 'NEW') New @elseif($log->status == 'DROP') Drop @else Answer @endif</td>
                    <td>{{$log->phone_number}}</td>
                    <td>{{$log->user}}</td>
                    <td>{{$log->called_count}}</td>
                    <td>{{$log->batchno}}</td>
                    </tr>
                  @endforeach
                  @endif
                    </table>
                    </div>
                    </div>
                </section>
            </div>
        </div>    
        <!-- page end--> 
@stop
@section('ScriptPage')
<script type="text/javascript">

  
$("#select_all").change(function(){
  //"select all" change
  var status = this.checked;
  // "select all" checked status
  $('.checkall').each(function(){
    //iterate all listed checkbox items
    this.checked = status; //change ".checkbox" checked status
  });
});
//     function resetbtn(compid) {

//     var arr= [];
//     var chkuserids = document.getElementsByName("chkuser[]");

//     var striginhseqs= "";
//     var usercount = 0;
//     for(var i = 0; i < chkuserids.length; i++)
//     {
//       if(chkuserids[i].checked == true)
//       {
//         usercount++;
//         arr.push(chkuserids[i].value);       
//       }   
//     }  
//     if(arr == ''){
//     //alert('no record');
//     document.getElementById('resetstatus').value = '1';
//     document.getElementById('submitbtn').click();
//     }
//     else if(arr != ''){
//         //alert(arr);
//     window.location = "{{ url('/').'/leads/list/' }}"+arr;
//     }

// }

    function resetbtn(compid) {

    var confirm_result = confirm("Are you sure you want to Reset?");
    if (confirm_result == true) {

    document.getElementById('resetstatus').value = '1';
    document.getElementById('submitbtn').click();
	}
    }

    function clearbtn(compid) {

    var confirm_result = confirm("Are you sure you want to Clear?");
    if (confirm_result == true) {

    document.getElementById('clearstatus').value = '1';
    document.getElementById('submitbtn').click();
	}
    }

  function exportexcel() {
    document.getElementById("exportstatus").value = '1';
    //alert("value");
    document.getElementById("submitbtn").click();
    document.getElementById("exportstatus").value = '0';
  }
</script>

@stop