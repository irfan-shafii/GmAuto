<!DOCTYPE html>
<html>
<head>
	<title>Read File</title>
</head>
<body>
@if(!empty($myfilename))
	{{$myfilename}}
<object data="{{$myfilename}}" width="100%" height="900">
Not supported
</object>
@else
No Files Found
@endif
</body>
</html>