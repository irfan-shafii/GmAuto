@extends('layouts.master')
@section('title', 'Add Upscale')
@section('breadCrumbs')
        
@stop

@section('pageBody')
 
        <div class="row">
            <div class="col-sm-12">
                
                    <form action="{{url('/')}}/upscale/store" method="post">
                        {{csrf_field()}}
                    <section class="panel">
                        <header class="panel-heading">
                            Upscale Details
                        </header>
                        <div class="panel-body">
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Upscale Topic</label>
                                    <input size="16" type="text" value="" name="topic" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                <label>Campaigns :</label>
                                  <select multiple name="campaigns[]" id="e9" style="width:300px" class="populate">
                                      <option value="">Select All</option>
                                      @foreach($campaigns as $camp)
                                      <option value="{{$camp->campaign_id}}">{{$camp->campaign_name}}</option>
                                      @endforeach
                                  </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="exampleInputEmail1">Vehicle Brand</label>
                                    <select class="form-control" name="brand" onChange="getmodel(this);">
										<option value="">Select</option>
										<option value="Chevrolet">Chevrolet</option>
										<option value="Cadillac">Cadillac</option>
                                    </select>
                                </div>
								<div class="form-group col-md-4" id="Chevroletdiv" style="display: none;">
								<label for="exampleInputEmail1">Vehicle Model</label>
								<select class="form-control" name="Chevrolet" id="Chevrolet" onChange="getbrand(this);">
								<option value="">Select</option>
								<option value="Aveo">Aveo</option>
								<option value="Blazer">Blazer</option>
								<option value="Captiva">Captiva</option>
								<option value="Corvette">Corvette</option>
								<option value="Bolt">Bolt</option>
								<option value="Camaro">Camaro</option>
								<option value="Silverado">Silverado</option>
								<option value="Equinox">Equinox</option>
								<option value="Express">Express</option>
								<option value="Impala">Impala</option>
								<option value="Malibu">Malibu</option>
								<option value="Sonic">Sonic</option>
								<option value="Spark">Spark</option>
								<option value="Suburban">Suburban</option>
								<option value="Tahoe">Tahoe</option>
								<option value="Trail Blazer">Trail Blazer</option>
								<option value="Traverse">Traverse</option>
								<option value="Trax">Trax</option>
								</select>
								</div>

								<div class="form-group col-md-4" id="Cadillacdiv" style="display: none;">
								<label for="exampleInputEmail1">Vehicle Model</label>
								<select class="form-control" name="Cadillac" id="Cadillac" onChange="getbrand(this);">
								<option value="">Select</option>
								<option value="ATS">ATS</option>
								<option value="ATS Coupe">ATS Coupe</option>
								<option value="CT5">CT5</option>
								<option value="CT6">CT6</option>
								<option value="CTS">CTS</option>
								<option value="CTS-V">CTS-V</option>
								<option value="Escalade">Escalade</option>
								<option value="XT4">XT4</option>
								<option value="XT5">XT5</option>
								<option value="XT6">XT6</option>
								<option value="XTS">XTS</option>
								</select>
								</div>
								<input type="hidden" name="model" id="model" value="">
                                <!-- <div class="col-md-12"></div> -->
                                <div class="form-group col-md-4">
                                    <label for="exampleInputPassword1">Description</label>
                                    <textarea type="text" class="form-control" name="description" id="message"></textarea>
                                </div>
                                <div class="form-group col-md-4">
                                <button type="submit" class="form-control btn btn-success btn-block">Submit</button>
                                <a href="javascript: history.go(-1)" class="form-control btn btn-danger btn-block">Close</a>
                                </div>
                            </form>

                        </div>
                    </section>
            </div>
        </div>
  
       
@stop
@section('ScriptPage')

<script type="text/javascript">
    function getmodel(idval){
    var model = idval.value;
    if(model == 'Chevrolet'){
          $("#Chevroletdiv").show();
          $("#Cadillacdiv").hide();

    }
    else if(model == 'Cadillac'){
          $("#Chevroletdiv").hide();
          $("#Cadillacdiv").show();
      
    }
    else{
      
          $("#Chevroletdiv").hide();
          $("#Cadillacdiv").hide();
    }

  	}

    function getbrand(idval){
    var model = idval.value;
          $("#model").val(model);
	}
</script>

@stop
