
<header class="panel-heading wht-bg" id="csidiv">
   <h4 class="gen-case"> CSI Questions
	<a href="#"  class="btn btn-info pull-right">
        {{$ingroup}} - {{$listname}}
    </a>
   </h4>
</header>
<div class="row" id="csibox">

<div class="col-lg-9">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Vehicles
</h3>
@if($listid == '999')
<div class="form-group col-md-4">
    <!-- <label for="exampleInput">List ID</label> -->
    <select name="list_id" id="list_id" class="form-control">
        <option value="">SELECT</option>
        @foreach($list_ids as $list)
        <option @if($list->list_id == $listid) selected="" @endif value="{{$list->list_id}}">{{$list->list_name}}</option>
        @endforeach
    </select>
</div>
@else
<input type="hidden" name="list_id" id="list_id" value="0">
@endif
</header>
<ul class="nav nav-pills" id="vehicle_csi_list">
</ul>

</section>

</div>

<div class="col-lg-3">
<section class="panel">
<div class="panel-body">


     <!--  <div class="pull-right mail-src-position">
        <div class="input-append">
            <input type="text" class="form-control " placeholder="Search..">
        </div>
    </div> -->

</div>
<div class="weather-category twt-category">
    <ul>
        <li>
            <h6 class="cusname" style="color: #5a5a5a;">750</h6>
            Name
        </li>
        <li>
            <h6 class="custarget" style="color: #5a5a5a;">750</h6>
            Target No
        </li>
        <li>
            <h6 class="cusphone" style="color: #5a5a5a;">750</h6>
            Phone No
        </li>
    </ul>
</div>
</section>
</div>
</div>
<style type="text/css">
div.answerDIV {
    height: 225px;
  overflow: auto;
}
</style>
<div class="panel-body">
    <div class="row">
        <div id="questionbox" style="display: none;font-size: 18px;">
            <div class="alert alert-success alert-block fade in col-md-12">
        	<div class="col-md-6">
                <h4 id="questionDIV"> 
                </h4>
            </div>
        	<div class="col-md-6">
                <h4 id="questionDIV1" style="text-align: right;direction: rtl;">
                </h4>
            </div>
            </div>
            <div class="col-md-12">
            <div class="well" style="font-size: 14px;">
                <div class="answerDIV">
                <div id="answerDIV" style="text-align: center;">
                    
                </div>
                <div id="desDIV"></div>
                <input type="hidden" id="descif" value="0">
                </div>
            </div>
            </div>
            <div class="col-md-12">
                <center>
                <h6 style='color:#F44336;display: none;' id="answertitle"></h6>
                <button type="button" id="prevbtn" class="btn btn-sm btn-danger" disabled="" onclick="getprevquestion();">Prev Question <i class="fa fa-backward"></i></button>
                <button type="button" id="nextbtn" class="btn btn-sm btn-success" disabled="" onclick="checknextquestion();"><i class="fa fa-forward"></i> Next Question</button>
                </center>
            </div>
        </div>
    </div>
                
                <input type="hidden" name="current_time" id="current_time" value="{{date('Y-m-d H:i:s')}}">
                <input type="hidden" id="questionid" name="questionid" value="0">

        <br>

        <!-- <ul id="prev_answers">
        </ul> -->

    <div class="row" id="answerbox" style="display: none;font-size: 18px;">
    <div class="row">
    <div class="col-md-12">
    <table class='table table-hover'>
        <tr>
            <th style="text-align: center;font-size: 14px;">Qno. </th>
            <th style="text-align: center;font-size: 14px;">In English </th>
            <th style="text-align: center;font-size: 14px;">In Arabic </th>
            <th style="text-align: center;font-size: 14px;">Answer</th>
        </tr>
        <tbody id="prev_answers" style="font-size: 14px;">
        </tbody>
    </table>
    </div>
    </div>
    </div>

</div>