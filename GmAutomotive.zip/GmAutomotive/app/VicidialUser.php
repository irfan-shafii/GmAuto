<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialUser extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_users";
    public $timestamps = false;
}
