<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKhisty80 extends Model
{
	protected $connection = 'mysql4';
    protected  $table="mk_80_histy";
}
