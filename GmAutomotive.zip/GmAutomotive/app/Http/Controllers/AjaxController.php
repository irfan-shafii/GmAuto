<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;
use App\MKnewst;
use App\VicidialLists;
use App\VicidialLiveAgent; 
use App\VicidialAutoCalls; 
use App\VicidialAgentLog; 
use App\VicidialLog; 
use App\VicidialCloserLog; 
use App\VicidialUser;
use App\VicidialList;  
use App\Average; 
use Session;

class AjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    
    public function getliveagents(Request $request)
    {
    if($request->ajax())
    {
            $count = 0; 
            $divhtml = ''; 
            $agenthtml = '';
            $queuehtml = '';

        $outbound_count = 0;
        $inbound_count = 0;
        $missed_count = 0;

        $queue_count = 0;

        if(isset($_POST['fromdate']) && !empty($_POST['fromdate'])) {

            $fromdate = $_POST['fromdate'];
            $todate = $_POST['todate'];
            $todate1 = $todate;
            //$todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

            $liveagents = VicidialLiveAgent::select('live_agent_id','user','extension','status','campaign_id','conf_exten','calls_today')->orderBy('status','asc')->get();
            $queue_count = VicidialAutoCalls::where('status','=','LIVE')->count();
            $count = count($liveagents);



            foreach ($liveagents as $live){
              $divhtml .= '<tr>';
                  $divhtml .= '<td>'.$live->extension.'</td>';
                  $divhtml .= '<td>'.$live->user.'</td>';
                  $divhtml .= '<td>'.$live->conf_exten.'</td>';
                  if ($live->status == 'CLOSER') {
                  $divhtml .= '<td><span class="label label-success label-mini">READY</span></td>';                      
                  }
                  else if ($live->status == 'INCALL') {
                  $divhtml .= '<td><span class="label label-success label-mini">'.$live->status.'</span></td>';                      
                  }
                  else if ($live->status == 'PAUSED') {
                  $divhtml .= '<td><span class="label label-warning label-mini">'.$live->status.'</span></td>';                      
                  }else{                   
                  $divhtml .= '<td><span class="label label-info label-mini">'.$live->status.'</span></td>';
                  }
                  $divhtml .= '<td>'.$live->campaign_id.'</td>';
                  //$divhtml .= '<td>'.$live->calls_today.'</td>';
              $divhtml .= '</tr>';
            }

        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000')->where('status','!=',null);
        $top_agents = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name')->orderBy('calls','desc')->skip(0)->take(20)->get();
        $agentcounts = VicidialAgentLog::select('user','event_time')->whereBetween('event_time',[$fromdate, $todate1])->where('status','!=',null)->count();


            foreach ($top_agents as $agent){
        $ainbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->where('user',$agent->user)->count();
        $aoutbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->where('user',$agent->user)->count();

                $ccount = Average::MathPER($agent->calls,$agentcounts);
              $agenthtml .= '<tr>';
                  $agenthtml .= '<td>'.$agent->full_name.'</td>';
                  $agenthtml .= '<td><span class="label label-danger label-mini">'.$agent->calls.'</span></td>'; 
                  $agenthtml .= '<td>'.$ainbound.'</td>';  
                  $agenthtml .= '<td>'.$aoutbound.'</td>';  
                  $agenthtml .= '<td>'.$ccount.'%</td>';
              $agenthtml .= '</tr>';
            }
            
        $queue_calls = VicidialAutoCalls::where('status','=','LIVE')->get();

            foreach ($queue_calls as $queue){
              $queuehtml .= '<tr>';
                  $queuehtml .= '<td><span class="label label-success label-mini">'.$queue->status.'</span></td>';
                  $queuehtml .= '<td>'.$queue->campaign_id.'</td>';
                  $queuehtml .= '<td>'.$queue->phone_number.'</td>';
                  $queuehtml .= '<td>'.$queue->server_ip.'</td>';
                  $queuehtml .= '<td>'.$queue->call_time.'</td>';
                  $queuehtml .= '<td>'.$queue->queue_priority.'</td>';
              $queuehtml .= '</tr>';
            }


        $outbound_count = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->count();
        $outbound_connected = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('length_in_sec','>','0')->count();
        $inbound_count = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->count();
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','=','DROP')->get();
        $missedtotal = $missed->count();

        foreach($missed as $mlog){
         $status_answer = VicidialCloserLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('closecallid','>',$mlog->closecallid)->where('status','!=','DROP')->where('length_in_sec','>','0')->count();
         $status_log = VicidialLog::where('phone_number',$mlog->phone_number)->where('call_date','>',$mlog->call_date)->where('length_in_sec','>','0')->count();

         if($status_answer == 0 && $status_log == 0 ){
           $missed_count++;
            }

       }


        $queue_count = VicidialAutoCalls::where('status','=','LIVE')->count();


        }
        echo json_encode(array("divhtml"=>$divhtml,"count"=>$count,"queue_count"=>$queue_count,"agenthtml"=>$agenthtml,"queuehtml"=>$queuehtml,"outbound_count"=>$outbound_count,"inbound_count"=>$inbound_count,"missed_count"=>$missed_count,"missedtotal"=>$missedtotal,"outbound_connected"=>$outbound_connected,"queue_count"=>$queue_count));
    }

    }

    public function customerinfo(Request $request){

    if($request->ajax()){

        if(isset($_POST['cusid']) && !empty($_POST['cusid'])) {


        $cusid = $_POST['cusid']; 
        $chasisid = $_POST['chasisid']; 

        $account = MKtargt::select('magic','firstnam','surname','phone002','phone004','address001','address002','address003','address004','socialid')->where('magic',$cusid)->get();
        $id_account = 0;
        if(count($account)>0){
            $id_account = $account[0]->magic;
            $fname = $account[0]->firstnam;
            $lname = $account[0]->surname;
            $mobile2 = $account[0]->phone004;
            $gender = '';
            $civilid = $account[0]->socialid;
            $address = $account[0]->address001.' '.$account[0]->address002.' '.$account[0]->address003.' '.$account[0]->address004;
        }

        if($chasisid != '0'){

        $vehicles = MKvehic::select('magic','regno','chassis')->join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic')->where('mk_00_vehic.chassis',$chasisid)->where('mk_00_vlink.ctmagic',$cusid)->get();
        if(count($vehicles) > 0){
            $chasisid = $vehicles[0]->magic;
        }
        }

        $divHtml = '';
        $divHtml1 = '';
        $divHtml2 = '';
        $divHtml3 = '';
        
        $vlinks = MKvlink::where('ctmagic',$id_account)->get();
        if(count($vlinks) > 0){

        $vehicles = MKvehic::select('magic','regno','modelvar','model','mileage','motdate')->join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic')->where('mk_00_vlink.ctmagic',$id_account)->get();

        if(count($vehicles)>0){
        foreach ($vehicles as $veh) {
          $divHtml .= '<li class="vcclist" id="vcclist'. $veh->magic .'"><a href="#" onclick="vehicleinfo('. $veh->magic .');"> <i class="fa fa-truck"></i>  ' . $veh->model.' - '. $veh->modelvar.' - '. $veh->regno .'</a></li>';
          $divHtml1 .= '<li class="vcc1list" id="vcc1list'. $veh->magic .'"><a href="#" onclick="vehicleinfo('. $veh->magic .');"> <i class="fa fa-truck"></i>  ' . $veh->model.' - '. $veh->modelvar.' - '. $veh->regno .'</a></li>';
          $divHtml2 .= '<li class="vcc2list" id="vcc2list'. $veh->magic .'"><a href="#" onclick="vehicleinfo('. $veh->magic .');"> <i class="fa fa-truck"></i>  ' . $veh->model.' - '. $veh->modelvar.' - '. $veh->regno .'</a></li>';
          $divHtml3 .= '<li class="vcc3list" id="vcc3list'. $veh->magic .'"><a href="#" onclick="vehicleinfo('. $veh->magic .');"> <i class="fa fa-truck"></i>  ' . $veh->model.' - '. $veh->modelvar.' - '. $veh->regno .'</a></li>';
        }
        }
        }

        //$vehicles = DB::table('vehicles')->where('id_account',$id_account)->get();

        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $account_comments = DB::table('opportunity')->where('id_account',$id_account)->orderBy('id_opp','desc')->get();


        $enqHTML = '';


        if(count($account_comments) > 0){
        foreach($account_comments as $comment){

            $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_category)->first();
            $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory)->first();
            $enq_category = '';
            $enq_subcategory = '';
            $enq_subcategory2 = '';
            $enq_subcategory3 = '';

             if(!empty($comment->enquiry_subcategory2) || $comment->enquiry_subcategory2 != '0'){

             $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory2)->first();

            if(count($enq_sub_cat2) > 0){
              $enq_subcategory2 = "<br>".$enq_sub_cat2->category_name;
            }

            }

            if(!empty($comment->enquiry_subcategory3) || $comment->enquiry_subcategory3 = '0'){

             $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory3)->first();

            if(count($enq_sub_cat3) > 0){
              $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
            }
             }
            if(count($enq_cat) > 0){
              $enq_category = $enq_cat->category_name;
            }
            if(count($enq_sub_cat) > 0){
              $enq_subcategory = $enq_sub_cat->category_name;
            }

          $enqHTML .='<tr>';
              $enqHTML .='<td>'.$comment->id_opp.'</td>';
              $enqHTML .='<td>'.$comment->id_agent.'</td>';
              $enqHTML .='<td>'.$comment->type_of_profession.'</td>';
              $enqHTML .='<td>'.$comment->date_add.'</td>';
              $enqHTML .='<td>'.$enq_category.'</td>';
              $enqHTML .='<td>'.$enq_subcategory.''.$enq_subcategory2.''.$enq_subcategory3.'</td>';
              $enqHTML .='<td>'.$comment->description.'</td>';
          $enqHTML .='</tr>';


        }
        }



        }
        echo json_encode(array("fname"=>$fname,"lname"=>$lname,"mobile2"=>$mobile2,"gender"=>$gender,"civilid"=>$civilid,"address"=>$address,"divHtml"=>$divHtml,"divHtml1"=>$divHtml1,"divHtml2"=>$divHtml2,"divHtml3"=>$divHtml3,"enqHTML"=>$enqHTML,"chasisid"=>$chasisid));
    }

    }
    

    public function vehicleinfo(Request $request)
    {
    if($request->ajax())
    {

        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

        $vehid = $_POST['vehid']; 
        $cusid = $_POST['cusid']; 

        $newst = MKnewst::select('vehmagic','exec','exec001','selllocn','invdate','regn','desc001','deldate','model')->where('vehmagic',$vehid)->get();

            $showroom = '';
            $salesman = '';
            $invoice = '';
            $regno = '';
            $description = '';
            $deldate = '';
            $availmodel = '';
        if(count($newst)>0){
            $showroom = $newst[0]->selllocn;
            $salesman = $newst[0]->exec.' ,'. $newst[0]->exec001;
            $invoice = $newst[0]->invdate;
            $regno = $newst[0]->regn;
            $description = $newst[0]->desc001;
            $deldate = $newst[0]->deldate;
            $availmodel = $newst[0]->model;
        }

        $vehicle = MKvehic::select('magic','regno','lastserv','modelvar','model','mileage','motdate','nextserv','colour','chassis','modelyr','mntstart','mntend','mntref','mntmile')->where('magic',$vehid)->get();
        //$vehicle = DB::table('vehicles')->where('id',$vehid)->get();
        if(count($vehicle)>0){
            $vehicleinfo = $vehicle[0]->modelvar;
            $vehmodel = $vehicle[0]->model;
            $vehyear = $vehicle[0]->modelyr;
            $vehcolor = $vehicle[0]->colour;
            $vehshowroom = $vehicle[0]->model;
            $plateno = $vehicle[0]->regno;
            $regdate = $vehicle[0]->lastserv;
            $chasisno = $vehicle[0]->chassis;
            $lastservice = $vehicle[0]->nextserv;
            $nextservice = $vehicle[0]->nextserv;

            $MOTDATE = $vehicle[0]->nextserv;
            $MILEAGE = $vehicle[0]->mileage;
            $LASTWORK = $vehicle[0]->nextserv;
            $mntstart = $vehicle[0]->mntstart;
            $mntend = $vehicle[0]->mntend;
            $mntref = $vehicle[0]->mntref;
            $mntmile = $vehicle[0]->mntmile;
        }
        else{

            $vehicleinfo = '';
            $vehmodel = '';
            $vehyear = '';
            $vehcolor = '';
            $vehshowroom = '';
            $plateno = '';
            $regdate = '';
            $chasisno = '';
            $lastservice = '';
            $nextservice = '';

            $MOTDATE = '';
            $MILEAGE = '';
            $LASTWORK = '';
            $mntstart = '';
            $mntend = '';
            $mntref = '';
            $mntmile = '';
        }

        $vehhisty = MKhisty::where('prime',$vehid)->where('tarmagic',$cusid)->orderBy('DATE','desc')->get();


          $histyHTML ='';
        if(count($vehhisty) > 0){
          foreach ($vehhisty as $histy) {
            if(!empty($histy->archive)){
                $archive = $histy->archive;
            }
            else{
                $archive = 0;
            }
          $histyHTML .='<tr>';
              $histyHTML .='<td><a href="'.url('/history').'/'.$archive.'" target="_blank" class="btn btn-success btn-xs"> '.$histy->code.' </a></td>';
              $histyHTML .='<td>'.$histy->date.'</td>';
              $histyHTML .='<td>'.$histy->miles.'</td>';
              $histyHTML .='<td>'.$histy->details.'</td>';
              $histyHTML .='<td>'.$histy->wipno.'</td>';
              $histyHTML .='<td>'.$histy->accno.'</td>';
              $histyHTML .='<td>'.$histy->value.'</td>';
              $histyHTML .='<td>'.$histy->invno.'</td>';
              $histyHTML .='<td>'.$histy->company.'</td>';
          $histyHTML .='</tr>';
        }

        }



        

        }
        echo json_encode(array("vehicleinfo"=>$vehicleinfo,"vehmodel"=>$vehmodel,"vehyear"=>$vehyear,"vehshowroom"=>$vehshowroom,"vehcolor"=>$vehcolor,"plateno"=>$plateno,"chasisno"=>$chasisno,"lastservice"=>$lastservice,"nextservice"=>$nextservice,"MOTDATE"=>$MOTDATE,"MILEAGE"=>$MILEAGE,"LASTWORK"=>$LASTWORK,"histyHTML"=>$histyHTML,"showroom"=>$showroom,"salesman"=>$salesman,"invoice"=>$invoice,"regno"=>$regno,"description"=>$description,"deldate"=>$deldate,"availmodel"=>$availmodel,"mntstart"=>$mntstart,"mntend"=>$mntend,"mntref"=>$mntref,"mntmile"=>$mntmile,"regdate"=>$regdate));
    }

    }





    public function getcategory(Request $request)
    {
    if($request->ajax())
    {
            $nexttype = 0; 
            $divhtml = ''; 
            $subvalue = 0;
            $apptab = "";

        if(isset($_POST['idvalue']) && !empty($_POST['idvalue'])) {

            $categoryid = $_POST['idvalue'];

            $category = DB::table('enquiry_categories')->where('id_enquiry_category',$categoryid)->first();
            $categorytype = $category->category_type;
            $categoryname = $category->category_name;

            if($categorytype =='1'){
            $nexttype = 2 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('category_name','asc')->get();

            }            
            else if($categorytype =='2'){

            $nexttype = 3 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('category_name','asc')->get();

            if($categoryid =='4' || $categoryid =='5' || $categoryid =='8' || $categoryid =='112' || $categoryid =='113' || $categoryid =='114' || $categoryid =='115' || $categoryid =='116' || $categoryid =='117' || $categoryid =='127' || $categoryid =='128' || $categoryid =='129' || $categoryid =='130' || $categoryid =='131' || $categoryid =='132' || $categoryid =='133' || $categoryid =='134' || $categoryid =='135' || $categoryid =='136' || $categoryid =='137'){
              $apptab = 1;
            }
            else{
              $apptab = 0;
            }

            }           
            else if($categorytype =='3'){
            $nexttype = 4 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('category_name','asc')->get();

            }  


            if($categorytype =='1' || $categorytype =='2' || $categorytype =='3'){
            $divhtml = ''; 
            if(count($enquiry_categories) > 0){

            //$divhtml .= '<select class="form-control" name="subcategory'.$categorytype.'" id="subcategory'.$nexttype.'" onChange="getcategory(this);" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($enquiry_categories as $enquiries) {
                $divhtml.='<option value="'.$enquiries->id_enquiry_category.'">'.$enquiries->category_name.'</option>'; 
            }
            //$divhtml.='</select>';


            }

            if ($categoryid == '113') {

            $events = DB::table('events')->where('delete_status','0')->get();

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3"  required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($events as $event) {
                $divhtml.='<option value="'.$event->name.'">'.$event->name.'</option>'; 
            }
            //$divhtml.='</select>';

            }

            else if ($categoryid == '114' || $categoryid == '132') {

            $campaigns = DB::table('campaigns')->where('delete_status','0')->get();

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($campaigns as $event) {
                $divhtml.='<option value="'.$event->name.'">'.$event->name.'</option>'; 
            }
            //$divhtml.='</select>';

            }

            else if ($categoryid == '118' || $categoryid == '119' || $categoryid == '134') {

            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
                $divhtml.='<option value="146">Excel Manual</option>'; 
            //$divhtml.='</select>';

            }

            else if ($categoryid == '128' || $categoryid == '129' || $categoryid == '130' || $categoryid == '131' || $categoryid == '133' || $categoryid == '138' || $categoryid == '139') {
                
            //$divhtml .= '<select class="form-control" name="subcategory3" id="subcategory3" required="">'; 
                $divhtml.='<option value="147">Kerridge</option>'; 
            //$divhtml.='</select>';

            }

            }

        }
        echo json_encode(array("divhtml"=>$divhtml,"categorytype"=>$categorytype,"subvalue"=>$subvalue,'categoryname'=>$categoryname,"apptab"=>$apptab));
    }

    }




    public function getlistids(Request $request)
    {
    if($request->ajax())
    {
            $campaign = 0;
            $divhtml = '';  

        if(isset($_POST['campaign']) && !empty($_POST['campaign'])) {

            $campaign = $_POST['campaign'];

            $lists = VicidialLists::select('list_id','list_name','campaign_id')->where('campaign_id',$campaign)->get();

            if(count($lists) > 0){

            //$divhtml .= '<select class="form-control" name="subcategory'.$categorytype.'" id="subcategory'.$nexttype.'" onChange="getcategory(this);" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($lists as $list) {
                $divhtml.='<option value="'.$list->list_id.'">'.$list->list_name.'</option>'; 
            }
            //$divhtml.='</select>';


            }

        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }


    public function getmodel(Request $request)
    {
    if($request->ajax())
    {
            $brand = 0;
            $divhtml = '';  

        if(isset($_POST['brand']) && !empty($_POST['brand'])) {

            $brand = $_POST['brand'];

            $brands = DB::table('brands')->where('name',$brand)->first();
            $models = DB::table('brand_models')->where('brand_id',$brands->id)->where('delete_status','0')->orderBy('id','asc')->get();

            if(count($models) > 0){

            $divhtml.='<option value="">Select</option>'; 
            foreach ($models as $model) {
                $divhtml.='<option value="'.$model->name.'">'.$model->name.'</option>'; 
            }


            }

        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }


    public function getbrand(Request $request)
    {
    if($request->ajax())
    {
            $brand = 0;
            $divhtml = '';  

        if(isset($_POST['brand']) && !empty($_POST['brand'])) {

            $brand = $_POST['brand'];

            $models = DB::table('brand_models')->where('name',$brand)->first();

            $brands = DB::table('brands')->where('id',$models->brand_id)->first();

                $divhtml = $brands->name; 


        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }


    public function getlisttarget(Request $request)
    {
    if($request->ajax())
    {
            $listid = 0;
            $divhtml = '';  

        if(isset($_POST['listid']) && !empty($_POST['listid'])) {

            $listid = $_POST['listid'];

            $listnames = VicidialLists::select('list_name')->where('list_id',$listid)->get();
            $listname =  '';
            if(count($listnames) > 0){
            $listname =  $listnames[0]->list_name;
            }

            $checklistid =  DB::table('target_lists')->where('list_id',$listid)->first();
            if($checklistid){ 

            $divhtml.='<div class="col-md-3"><p>Listname - <b>'.$listname.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Total Target - <b>'.$checklistid->totaltarget.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Achieved Target - <b>'.$checklistid->achieved.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Remaining Target - <b>'.$checklistid->remaining.'</b></p></div>'; 

            $checkbtaches =  DB::table('target_batches')->where('active','Y')->where('list_id',$listid)->orderBy('id','desc')->get();
            foreach ($checkbtaches as $checkbtach) {
            $divhtml.='<div class="col-md-3"><p>Batch No - <b>'.$checkbtach->batchno.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Total Target - <b>'.$checkbtach->totaltarget.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Achieved Target - <b>'.$checkbtach->achieved.'</b></p></div>'; 
            $divhtml.='<div class="col-md-3"><p>Remaining Target - <b>'.$checkbtach->remaining.'</b></p></div>'; 
            }


            }

        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }

    public function getbatchtarget(Request $request)
    {
    if($request->ajax())
    {
            $listid = 0;
            $target = 0;
            $achieved = 0;
            $listtarget = 0;
            $divhtml = '';  

        if(isset($_POST['batchid']) && !empty($_POST['batchid'])) {

            $batchid = $_POST['batchid'];


            $checkbtach =  DB::table('target_batches')->where('id',$batchid)->first();
            if($checkbtach){ 

            $target = $checkbtach->totaltarget;
            $achieved = $checkbtach->achieved;
            $listid = $checkbtach->list_id;
            $checklistid =  DB::table('target_lists')->where('list_id',$listid)->first();

            if($checklistid){ 
              $listtarget = $checklistid->totaltarget;
            }

            }


        }
        echo json_encode(array("target"=>$target,"achieved"=>$achieved,"listtarget"=>$listtarget));
    }

    }


    public function getlistbatch(Request $request)
    {
    if($request->ajax())
    {
            $list = 0;
            $divhtml = '';  
        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        if(isset($_POST['list']) && !empty($_POST['list'])) {

            $list = $_POST['list'];

        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$list)->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        $batcount = 1;
            $divhtml.='<option value="">Select</option>'; 
          foreach ($batches as $batche) {

                $divhtml.='<option value="'.$batche->batchno.'">'.$batche->batchno.'</option>'; 
            
          }

        }
        echo json_encode(array("divhtml"=>$divhtml));
    }

    }


    public function changestatus(Request $request)
    {
    if($request->ajax())
    {
            $status = 0;
            $divhtml = '';  

        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $statuslist = VicidialLists::select('list_id','active')->where('list_id',$idval)->first();
            $status = $statuslist->active;

            if($status == 'Y'){

            VicidialLists::where('list_id',$idval)->update(['active' => 'N']);
            $divhtml = '<a href="#" class="btn btn-space btn-xs btn-danger" onclick="changestatus('.$idval.')"> In Active </a>'; 

            }

            if($status == 'N'){

            VicidialLists::where('list_id',$idval)->update(['active' => 'Y']);
            $divhtml = '<a href="#" class="btn btn-space btn-xs btn-success" onclick="changestatus('.$idval.')"> Active </a>'; 

            }

        }
        echo json_encode(array("divhtml"=>$divhtml,"status"=>$status));
    }

    }


    public function changebatchstatus(Request $request)
    {
    if($request->ajax())
    {
            $status = 0;
            $divhtml = '';  

        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $statuslist = DB::table('target_batches')->select('list_id','active','batchno')->where('id',$idval)->first();
            $status = $statuslist->active;
            $list_id = $statuslist->list_id;
            $batchno = $statuslist->batchno;

            if($status == 'Y'){

            VicidialList::where('list_id',$list_id)->where('batchno',$batchno)->where('status','NEW')->update(['status'=>'DA']);
            DB::table('target_batches')->where('id',$idval)->update(['active'=>'N']);
            $divhtml = '<a href="#" class="btn btn-space btn-xs btn-danger" onclick="changestatus('.$idval.')"> In Active </a>'; 

        $description = 'Batch target deactivated';
        DB::table('target_logs')->insert(['listid'=>$list_id,'batchid'=>$batchno,'description'=>$description,'created_by'=>Session::get('userid')]); 

            }

            if($status == 'N'){

            VicidialList::where('list_id',$list_id)->where('batchno',$batchno)->where('status','DA')->update(['status'=>'NEW']);
            DB::table('target_batches')->where('list_id',$list_id)->update(['active'=>'N']);
            DB::table('target_batches')->where('id',$idval)->update(['active'=>'Y']);
            $divhtml = '<a href="#" class="btn btn-space btn-xs btn-success" onclick="changestatus('.$idval.')"> Active </a>'; 
        $description = 'Batch target activated';
        DB::table('target_logs')->insert(['listid'=>$list_id,'batchid'=>$batchno,'description'=>$description,'created_by'=>Session::get('userid')]); 

            }

        }
        echo json_encode(array("divhtml"=>$divhtml,"status"=>$status));
    }

    }



    public function getquestion(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['questionid']) && !empty($_POST['questionid'])) {

            $questionid = $_POST['questionid'];
            $question = $_POST['question'];
            $question1 = $_POST['question1'];
            $answer = $_POST['answer'];
            $description = $_POST['description'];
            $mobile = $_POST['mobile'];
            $user = $_POST['user'];
            $ctime = $_POST['ctime'];
            $id_account = $_POST['id_account'];
            $vehid = $_POST['vehid'];
            $masterid = $_POST['masterid'];

            $vehbrand = $_POST['vehbrand'];
            $vehmodel = $_POST['vehmodel'];
            $dealer = $_POST['dealer'];
            $dealer = 'Yusuf Ahmed Alghanim & Sons';
            $mileage = $_POST['mileage'];
            $showroom = $_POST['showroom'];
            $year = $_POST['vehyear'];
            $regdate = $_POST['regdate'];
            $userinfo = $_POST['userinfo'];
            $fullname = $_POST['fullname'];
            $advisor1 = "<br><b style='color:#F44336;'> ".$_POST['advisor1']."</b>";
            $advisor2 = "<br><b style='color:#F44336;'> ".$_POST['advisor2']."</b>";
            $salesman = "<br><b style='color:#F44336;'> ".$_POST['salesman']."</b>";

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>", "<USER>", "<NAME>", "<MILEAGE>", "<ADVISOR>", "<ADVISOR1>", "<SALESMAN>"];
            $vehicle_val   = [$vehbrand,$vehmodel,$dealer,$showroom,$year,$regdate,$userinfo,$fullname,$mileage,$advisor1,$advisor2,$salesman];

            $prevmaster = DB::table('csi_master')->where('agent_id',$userinfo)->where('mobile',$mobile)->where('date_time',$ctime)->where('id_account',$id_account)->where('vehmagic',$vehid)->where('list_id',$user)->count();
            if($prevmaster == 0){
            $masterid = DB::table('csi_master')->insertGetId(['id_account'=>$id_account,'agent_id'=>$userinfo,'mobile'=>$mobile,'date_time'=>$ctime,'vehmagic'=>$vehid,'list_id'=>$user,'serviceadvisor'=>$_POST['advisor1'],'deliveryadvisor'=>$_POST['advisor2'],'salesman'=>$_POST['salesman']]);
            }

            $prevanswer = DB::table('csi_answers')->where('question_id',$questionid)->where('mobile_number',$mobile)->where('date_time',$ctime)->where('id_account',$id_account)->where('vehicle_id',$vehid)->where('listid',$user)->get();
            if(count($prevanswer) > 0){
            DB::table('csi_answers')->where('question_id',$questionid)->where('mobile_number',$mobile)->where('date_time',$ctime)->where('id_account',$id_account)->where('vehicle_id',$vehid)->update(['answer'=>$answer,'description'=>$description]);
            }
            else{
            DB::table('csi_answers')->insert(['question'=>$question,'in_arabic'=>$question1,'question_id'=>$questionid,'answer'=>$answer,'description'=>$description,'mobile_number'=>$mobile,'userid'=>$userinfo,'date_time'=>$ctime,'id_account'=>$id_account,'vehicle_id'=>$vehid,'listid'=>$user,'master_id'=>$masterid]);
            }
            DB::table('csi_master')->where('id',$masterid)->update(['serviceadvisor'=>$_POST['advisor1'],'deliveryadvisor'=>$_POST['advisor2'],'salesman'=>$_POST['salesman']]);

            $description="";
            $previous_content = "";
            $previous_content1 = "";
            $nxtques = "";
            $nxtques1 = "";
            $nxtquesid = "";
            $nextans = "";
            $anstype = 0;
            $descif = 0;

            if ($user >= 4000 && $user <= 4008) {
            $list_id = 1004;
            }
            else if ($user >= 3001 && $user <= 3017) {
            $list_id = 1004;
            }
            else if ($user == 2003 || $user == 2004) {
            $list_id = 1004;
            }
            else if ($user >= 5000 && $user <= 5007) {
            $list_id = 1009;
            }
            else if ($user == 5008) {
            $list_id = 1008;
            }
            else if ($user == 5009) {
            $list_id = 1008;
            }
            else{
            $list_id = $user;
            }

            $questiondetails = DB::table('csi_questions')->where('listid',$list_id)->where('id',$questionid)->first();

            $questionparent = DB::table('csi_questions')->where('listid',$list_id)->where('id',$questiondetails->child_id)->get();

            if(count($questionparent) > 0){
            $nxtques = '<b>'.$questionparent[0]->qtype.'.</b> '.$questionparent[0]->question;
            $nxtques1 = $questionparent[0]->in_arabic;
            $nxtquesid = $questionparent[0]->id;
            $anstype = $questionparent[0]->anstype;
            $descif = $questionparent[0]->descif;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }
            else{

            $questionchild = DB::table('csi_questions')->where('listid',$list_id)->where('parent_id',$questionid)->where('ansif', 'like', '%'.$answer.'%')->get();
            if(count($questionchild) > 0){

            $questionchilds = DB::table('csi_questions')->where('listid',$list_id)->where('parent_id',$questionid)->where('ansif', '!=', '0')->get();
            foreach ($questionchilds as $questionch) {

            DB::table('csi_answers')->where('master_id',$masterid)->where('question_id',$questionch->id)->delete();

            }
            $nxtques = '<b>'.$questionchild[0]->qtype.'.</b> '.$questionchild[0]->question;
            $nxtques1 = $questionchild[0]->in_arabic;
            $nxtquesid = $questionchild[0]->id;
            $anstype = $questionchild[0]->anstype;
            $descif = $questionchild[0]->descif;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }

            }

            if($descif == '1'){            
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else if ($anstype == "4" || $anstype == "5" || $anstype == "7" || $anstype == "8" || $anstype == "9" || $anstype == "10" || $anstype == "16"){            
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else if (in_array($nxtquesid, array(6, 7, 8, 21, 37, 53, 58))){            
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else{               
              $description='<input type="hidden" id="description" value="">'; 
            }

            $prev_answers = DB::table('csi_answers')->where('master_id',$masterid)->orderBy('id','asc')->get();

            foreach ($prev_answers as $prev) {      

            $prev_ques = DB::table('csi_questions')->where('listid',$list_id)->where('id',$prev->question_id)->get();
            $prevques1  = $prev_ques[0]->in_arabic;
            $prevques  = $prev_ques[0]->question;
            $prevqtype  = $prev_ques[0]->qtype;
            $prevans  = $prev->answer;
            $prevdesc  = $prev->description;
            $prevquestion1 = str_replace($vehicle_det, $vehicle_val, $prevques1);
            $prevquestion = str_replace($vehicle_det, $vehicle_val, $prevques);

            $previous_content .= "
                                  <tr>
                                  <td>".$prevqtype."</td>
                                  <td>".$prevquestion."</td>
                                  <td style='text-align: right;direction: rtl;'>".$prevquestion1."</td>
                                  <td><h5><b style='color:#7b9a46;'>".$prev->answer."</b></h5><h5><b style='color:#F44336;'>".$prev->description."</b></h5></td>
                                  </tr>";
            }

            if (empty($nxtques)) {
              $nxtques = 'Thank you for your feedback.  It will help us to improve the level of service provided to you.';

              $nxtques1 = 'شكراً لك على المعلومات التي زودتنا بها والتي ستساعدنا من أجل تحسين مستوى خدماتها المقدمة لك.     ';
              $nxtquesid = '0';
              $nextans = '<div class="btn-group"><a class="btn btn-sm btn-block btn-danger" onclick="getprevquestion();">Prev Question <i class="fa fa-backward"></i></a> <a class="btn btn-sm btn-block btn-info" onclick="clearbox();"><i class="fa fa-thumbs-o-up"></i> Done</a></div>';
              $description=''; 
            }

            
            $prev_ans = "";
            $prev_answer = DB::table('csi_answers')->where('master_id',$masterid)->where('question_id',$nxtquesid)->first();
            if ($prev_answer) {
            $prev_ans  = $prev_answer->answer;
            }

          }
        echo json_encode(array("question"=>$nxtques,"question1"=>$nxtques1,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"descif"=>$descif,"previous"=>$previous_content,"previous1"=>$previous_content1,"masterid"=>$masterid,"anstype"=>$anstype,"prevans"=>$prev_ans));
        }

    }

    public function getprevquestion(Request $request)
    {
    if($request->ajax())
    {

            $nxtques = "";
            $nxtques1 = "";
            $nxtquesid = 0;
            $nextans = "";
            $description = "";
            $descif = "";
            $anstype = "";
            $prevans = "";

        if(isset($_POST['masterid']) && !empty($_POST['masterid'])) {

          $questionid = $_POST['questionid'];
          $masterid = $_POST['masterid'];

          $lastadded = DB::table('csi_answers')->where('master_id',$masterid)->orderBy('id','desc')->get(); 
          if($questionid > 0){
          $currentadded = DB::table('csi_answers')->where('master_id',$masterid)->where('question_id',$questionid)->orderBy('id','desc')->first();

            if($currentadded){  
            $lastadded = DB::table('csi_answers')->where('master_id',$masterid)->where('id','<',$currentadded->id)->orderBy('id','desc')->get(); 
            }
            else{
              $lastadded = DB::table('csi_answers')->where('master_id',$masterid)->orderBy('id','desc')->get();              
            }

          }

          if(count($lastadded) > 0){
            $lastid = $lastadded[0]->id;
            $questionid = $lastadded[0]->question_id;      


            $nxtques = $lastadded[0]->question;
            $nxtques1 = $lastadded[0]->in_arabic;
            $nxtquesid = $lastadded[0]->question_id;
            $prevans = $lastadded[0]->answer;

            $questiondetails = DB::table('csi_questions')->where('id',$nxtquesid)->first();

            $anstype = $questiondetails->anstype;
            $descif = $questiondetails->descif;

            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->first();
            $nextans = $anstypes->answertype;


            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }


            if($descif == '1'){            
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else if ($anstype == "4" || $anstype == "5" || $anstype == "7" || $anstype == "8" || $anstype == "9" || $anstype == "10" || $anstype == "16"){        
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else if (in_array($nxtquesid, array(6, 7, 8, 21, 37, 53, 58))){         
              $description='<br><textarea class="form-control" placeholder="Specify Notes..." id="description"></textarea>'; 
            }
            else{               
              $description='<input type="hidden" id="description" value="">'; 
            }

            }


          }
        echo json_encode(array("question"=>$nxtques,"question1"=>$nxtques1,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"descif"=>$descif,"anstype"=>$anstype,"prevans"=>$prevans));
        }

    }


    public function getsalesman(Request $request)
    {
    if($request->ajax())
    {
            $showroom = "";
            $divhtml = "";
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $showrooms = DB::table('showrooms')->where('id',$idval)->get();
            if (count($showrooms) > 0) {
               $showroom = $showrooms[0]->name;
            }

            $salesman = DB::table('salesmans')->where('showroom_id',$idval)->where('delete_status','0')->get();


            $divhtml.='<option value="">Select</option>'; 
            foreach ($salesman as $sales) {
                $divhtml.='<option value="'.$sales->name.'">'.$sales->name.'</option>'; 
            }


          }
        echo json_encode(array("showroom"=>$showroom,"divhtml"=>$divhtml));
        }

    }


    public function getadvisor(Request $request)
    {
    if($request->ajax())
    {
            $showroom = "";
            $divhtml = "";
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $showrooms = DB::table('service_centers')->where('id',$idval)->get();
            if (count($showrooms) > 0) {
               $showroom = $showrooms[0]->name;
            }

            $salesman = DB::table('sale_advisors')->where('center_id',$idval)->where('delete_status','0')->get();


            $divhtml.='<option value="">Select</option>'; 
            foreach ($salesman as $sales) {
                $divhtml.='<option value="'.$sales->name.'">'.$sales->name.'</option>'; 
            }


          }
        echo json_encode(array("showroom"=>$showroom,"divhtml"=>$divhtml));
        }

    }

    public function getadvisorname(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

            $vehmagic = $_POST['vehid'];
            $list_id = $_POST['list_id'];
            $brand = $_POST['vehmodel'];

            if ($list_id >= 4000 && $list_id <= 4002) {
            $centre = 'SO_25';
            }
            else if ($list_id >= 3001 && $list_id <= 3017) {
            $centre = 'SO_13';
            }
            else {
            $centre = 'SO_13';
            }

            $BookedInOperator = ' not found';
            $BookedOutOperator = ' not found';
            $OperatorName = ' not found';
            $OperatorName1 = ' not found';
            $InOperator = '';
            $OutOperator = '';


            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA = "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT  ".$centre."_Headr.BookedInOperator, ".$centre."_Headr.BookedOutOperator,".$centre."_Headr.WLInOut, ".$centre."_Headr.WLDateIn, ".$centre."_Headr.BookingStatus, ".$centre."_Headr.WIPNumber,".$centre."_Headr.Registration, ".$centre."_Headr.MagicMKVehicle, ".$centre."_Headr.Status FROM ".$centre."_Headr WHERE ( ".$centre."_Headr.WLDateOut Is Null) AND ( ".$centre."_Headr.WLInOut='IN') AND ( ".$centre."_Headr.MagicMKVehicle in (' ".$vehmagic." ')) AND (".$centre."_Headr.WLDateIn>{d '".$date90."'})\"\r\n}";
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if (!empty($data['data'])) {
            if($data['code'] == '200'){
            $BookedInOperator = $data['data'][0]['BookedInOperator'];
            $BookedOutOperator = $data['data'][0]['BookedOutOperator'];
            $InOperator = intval($BookedInOperator);
            $OutOperator = intval($BookedOutOperator);
            }
            }

            if(!empty($InOperator)){
            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA =  "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT ".$centre."_opers.OperatorCode, ".$centre."_opers.OperatorNumber, ".$centre."_opers.OperatorName from ".$centre."_opers where ".$centre."_opers.OperatorCode='".$InOperator."'\"\r\n}";
           

            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if (!empty($data['data'])) {
            if($data['code'] == '200'){
            $OperatorName = $data['data'][0]['OperatorName'];
            }
            }
            }  
            

            if(!empty($OutOperator)){      

            $curl = curl_init();
            // $centre = 'SO_13';
            // $vehmagic = '633111';
            // $brand = 'Chevrolet';
            $date90 = date('Y-m-d', strtotime("-90 day"));
            //echo $date90;
            $sendDATA =  "{\r\n\r\n    \"brand\":\"".$brand."\",\r\n    \"query\": \"SELECT ".$centre."_opers.OperatorCode, ".$centre."_opers.OperatorNumber, ".$centre."_opers.OperatorName from ".$centre."_opers where ".$centre."_opers.OperatorCode='".$OutOperator."'\"\r\n}";
           

            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://172.16.5.69/odbc/getdetailsfromodbc",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_POSTFIELDS =>$sendDATA,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
            ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            //echo $response;
            $data = json_decode($response, true);
            if($data['code'] == '200'){
            $OperatorName1 = $data['data'][0]['OperatorName'];
            }
            }


          }
        echo json_encode(array("OperatorName"=>$OperatorName,"OperatorName1"=>$OperatorName1));
        }

    }


    public function getcsi(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

            $mobile = $_POST['mobile'];
            $user = $_POST['user'];
            $ctime = $_POST['ctime'];
            $id_account = $_POST['id_account'];
            $vehid = $_POST['vehid'];

            $vehbrand = $_POST['vehbrand'];
            $vehmodel = $_POST['vehmodel'];
            $dealer = $_POST['dealer'];
            $dealer = 'Yusuf Ahmed Alghanim & Sons';
            $mileage = $_POST['mileage'];
            $showroom = $_POST['showroom'];
            $year = $_POST['vehyear'];
            $regdate = $_POST['regdate'];
            $userinfo = $_POST['userinfo'];
            $fullname = $_POST['fullname'];
            $advisor1 = "<br><b style='color:#F44336;'> ".$_POST['advisor1']."</b>";
            $advisor2 = "<br><b style='color:#F44336;'> ".$_POST['advisor2']."</b>";
            $salesman = "<br><b style='color:#F44336;'> ".$_POST['salesman']."</b>";

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>", "<USER>", "<NAME>", "<MILEAGE>", "<ADVISOR>", "<ADVISOR1>", "<SALESMAN>"];
            $vehicle_val   = [$vehbrand,$vehmodel,$dealer,$showroom,$year,$regdate,$userinfo,$fullname,$mileage,$advisor1,$advisor2,$salesman];


            $description="";
            $previous_content = "";
            $previous_content1 = "";
            $nxtques = "";
            $nxtques1 = "";
            $nxtquesid = "";
            $nextans = "";
            $nextans1 = "";


            if ($user >= 4000 && $user <= 4008) {
            $list_id = 1004;
            }
            else if ($user >= 3001 && $user <= 3017) {
            $list_id = 1004;
            }
            else if ($user == 2003 || $user == 2004) {
            $list_id = 1004;
            }
            else if ($user >= 5000 && $user <= 5007) {
            $list_id = 1009;
            }
            else if ($user == 5008) {
            $list_id = 1008;
            }
            else if ($user == 5009) {
            $list_id = 1008;
            }
            else{
            $list_id = $user;
            }

            $questiondetails = DB::table('csi_questions')->where('listid',$list_id)->where('parent_id','0')->get();

            if(count($questiondetails) > 0){
            $nxtques = $questiondetails[0]->question;
            $nxtques1 = $questiondetails[0]->in_arabic;
            $nxtquesid = $questiondetails[0]->id;
            $anstype = $questiondetails[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            $nxtques1 = str_replace($vehicle_det, $vehicle_val, $nxtques1);
            }


            if(empty($description)){               
              $description='<input type="hidden" id="description" value="">'; 
            }



            $prev_answers = DB::table('csi_answers')->where('mobile_number',$mobile)->where('date_time',$ctime)->where('id_account',$id_account)->where('vehicle_id',$vehid)->orderBy('id','asc')->get();

            foreach ($prev_answers as $prev) {      

            $prev_ques = DB::table('csi_questions')->where('listid',$list_id)->where('id',$prev->question_id)->get();
            $prevques1  = $prev_ques[0]->in_arabic;
            $prevques  = $prev_ques[0]->question;
            $prevquestion1 = str_replace($vehicle_det, $vehicle_val, $prevques1);
            $prevquestion = str_replace($vehicle_det, $vehicle_val, $prevques);
            
            $previous_content .= "
                                  <tr>
                                  <td>".$prevquestion."</td>
                                  <td style='text-align: right;direction: rtl;'>".$prevquestion1."</td>
                                  <td><h5><b style='color:#7b9a46;'>".$prev->answer."</b></h5><h5><b style='color:#F44336;'>".$prev->description."</b></h5></td>
                                  </tr>";

            }

            if (empty($nxtques)) {
              $nxtques = 'Thank you for your feedback.  It will help us to improve the level of service provided to you.';

              $nxtques1 = 'شكراً لك على المعلومات التي زودتنا بها والتي ستساعدنا من أجل تحسين مستوى خدماتها المقدمة لك.     ';
              $nxtquesid = '0';
              $nextans = '<div class="btn-group"><a class="btn btn-info" onclick="clearbox();">Done</a></div>';
              $description=''; 
            }



          }
        echo json_encode(array("question"=>$nxtques,"question1"=>$nxtques1,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"previous"=>$previous_content,"previous1"=>$previous_content1));
        }

    }



    public function edit_csi(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

            $idval = $_POST['idval'];

            $year = '2020';

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>", "<DATE>"];
            $vehicle_val   = [$year,$year,$year,$year,$year,$year];
            $description="";
            $nxtques = "";
            $nxtquesid = "";
            $nextans = "";


            $answers = DB::table('csi_answers')->where('id',$idval)->get();
            $questionid = $answers[0]->question_id;

            $questiondetails = DB::table('csi_questions')->where('id',$questionid)->get();

            if(count($questiondetails) > 0){
            $nxtques = $questiondetails[0]->question;
            $nxtquesid = $questiondetails[0]->id;
            $anstype = $questiondetails[0]->anstype;
            $anstypes = DB::table('csi_answertype')->select('answertype')->where('id',$anstype)->get();
            if(count($anstypes) > 0){
            $nextans = $anstypes[0]->answertype;
            }

            $nxtques = str_replace($vehicle_det, $vehicle_val, $nxtques);
            }


            if(empty($description)){               
              $description='<input type="hidden" id="description" value="">'; 
            }

          }
        echo json_encode(array("question"=>$nxtques,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description));
        }

    }


    public function getusergroup(Request $request)
    {
      $divhtml = '';
    if($request->ajax())
    {
        if(isset($_POST['group']) && !empty($_POST['group'])) {

        $group = $_POST['group'];

        $users = VicidialUser::select('active','user_id','user','user_group')->where('active','Y')->orderBy('user','asc')->get();

      $divhtml .= '<select name="users[]" id="e9" class="populate" required="" multiple="" style="width: 350px;">';
      $divhtml .= '<option value="">Select</option>';
      foreach($users as $user){
      $usersc = VicidialUser::select('active','user_group')->where('user_group',$group)->where('active','Y')->count();  
      if ($usersc > 0) {
      $divhtml .= '<option value="'.$user->user_id.'" selected="">'.$user->user.'</option>';
      }
      else{
      $divhtml .= '<option value="'.$user->user_id.'">'.$user->user.'</option>';
      }
      }
      $divhtml .= '</select>';

          }
        echo json_encode(array("divhtml"=>$divhtml));
        }

    }


    public function getbatch(Request $request)
    {
      $divhtml = '';
    if($request->ajax())
    {
        if(isset($_POST['idval']) && !empty($_POST['idval'])) {

        $idval = $_POST['idval'];
        $fromdate = $_POST['fromdate'];
        $todate1 = $_POST['todate'];
        $batch1 = '0,0,0,0,0';
        $batch2 = '0,0,0,0,0';
        $batch3 = '0,0,0,0,0';
        $batch4 = '0,0,0,0,0';
        $list1 = '';
        $list2 = '';
        $list3 = '';
        $list4 = '';

 $listnames = VicidialLists::select('list_name')->where('list_id',$idval)->get();
    $listname =  '';
    if(count($listnames) > 0){
       $listname =  $listnames[0]->list_name;
    }

        //$batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('lead_id','>','0')->where('batchno','!=','')->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();

            $batches =  DB::table('target_batches')->where('active','Y')->where('list_id',$idval)->orderBy('id','desc')->get();
        $batcount = 1;
          foreach ($batches as $batche) {

          $dial_lists_new = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('status','NEW')->where('batchno',$batche->batchno)->count();
          $dial_lists_ans = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('status','answer')->where('batchno',$batche->batchno)->count();
          $dial_lists_b = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('status','B')->where('batchno',$batche->batchno)->count();
          $dial_lists_na = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('status','NA')->where('batchno',$batche->batchno)->count();
          $dial_lists_drop = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$idval)->where('status','DROP')->where('batchno',$batche->batchno)->count();

          ${"batch" . $batcount} = $dial_lists_new.','.$dial_lists_ans.','.$dial_lists_b.','.$dial_lists_na.','.$dial_lists_drop;
          ${"list" . $batcount} = $listname.' - '.$batche->batchno;

          $divhtml .= '<div class="col-sm-12 panel" style="width: 375px;"><canvas id="pie-chartbatch'.$batcount.'"></canvas></div>';
          $batcount++;

          }


          }
        echo json_encode(array("list1"=>$list1,"list2"=>$list2,"list3"=>$list3,"list4"=>$list4,"batch1"=>$batch1,"batch2"=>$batch2,"batch3"=>$batch3,"batch4"=>$batch4,"divhtml"=>$divhtml,"batcount"=>$batcount,"listname"=>$listname));
        }

    }

    public function gettxtdocument(Request $request)
    {
    if($request->ajax())
    {
        if(isset($_POST['newURL']) && !empty($_POST['newURL'])) {

            $txtdoc = $_POST['newURL'];

          }
        echo json_encode(array("txtdoc"=>$txtdoc));
        }

    }




    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
