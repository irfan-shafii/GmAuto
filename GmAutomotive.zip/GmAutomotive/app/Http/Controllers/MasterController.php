<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class MasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function events(Request $request)
    {
        $events = DB::table('events')->where('delete_status','0')->get();
        return view('master.index',compact('events'));
    }


    public function eventstore(Request $request)
    {
        DB::table('events')->insert(['name' => $request->name,'description' => $request->description]);
        return redirect('/master/events');
    }

    public function brands(Request $request)
    {
        $brands = DB::table('brands')->where('delete_status','0')->get();
        return view('master.brand',compact('brands'));
    }


    public function brandstore(Request $request)
    {
        DB::table('brands')->insert(['name' => $request->name,'description' => $request->description]);
        return redirect('/master/brands');
    }

    public function models(Request $request)
    {
        $models = DB::table('brand_models')->where('delete_status','0')->get();
        $brands = DB::table('brands')->where('delete_status','0')->get();
        return view('master.model',compact('models','brands'));
    }


    public function modelstore(Request $request)
    {
        DB::table('brand_models')->insert(['brand_id' => $request->brand_id,'name' => $request->name]);
        return redirect('/master/models');
    }

    public function campaigns(Request $request)
    {
        $campaigns = DB::table('campaigns')->where('delete_status','0')->get();
        return view('master.campaigns',compact('campaigns'));
    }


    public function campaignstore(Request $request)
    {
        DB::table('campaigns')->insert(['name' => $request->name,'description' => $request->description]);
        return redirect('/master/campaigns');
    }

    public function showroom(Request $request)
    {
        $showrooms = DB::table('showrooms')->where('delete_status','0')->get();
        return view('master.showroom',compact('showrooms'));
    }


    public function showroomstore(Request $request)
    {
        DB::table('showrooms')->insert(['name' => $request->name,'description' => $request->description]);
        return redirect('/master/showroom');
    }

    public function salesman(Request $request)
    {
        $showrooms = DB::table('showrooms')->where('delete_status','0')->get();
        $salesmans = DB::table('salesmans')->where('delete_status','0')->get();
        return view('master.salesman',compact('salesmans','showrooms'));
    }


    public function salesmanstore(Request $request)
    {
        DB::table('salesmans')->insert(['showroom_id' => $request->showroom_id,'name' => $request->name,'description' => $request->description]);
        return redirect('/master/salesman');
    }

    public function center(Request $request)
    {
        $showrooms = DB::table('service_centers')->where('delete_status','0')->get();
        return view('master.center',compact('showrooms'));
    }


    public function centerstore(Request $request)
    {
        DB::table('service_centers')->insert(['name' => $request->name,'description' => $request->description]);
        return redirect('/master/center');
    }

    public function advisor(Request $request)
    {
        $showrooms = DB::table('service_centers')->where('delete_status','0')->get();
        $salesmans = DB::table('sale_advisors')->where('delete_status','0')->get();
        return view('master.advisor',compact('salesmans','showrooms'));
    }


    public function advisorstore(Request $request)
    {
        DB::table('sale_advisors')->insert(['center_id' => $request->center_id,'name' => $request->name,'description' => $request->description]);
        return redirect('/master/advisor');
    }




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroyevent($id)
    {
        DB::table('events')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/event');
    }

    public function destroycampaigns($id)
    {
        DB::table('campaigns')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/campaigns');
    }

    public function destroyshowroom($id)
    {
        DB::table('showrooms')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/showroom');
    }

    public function destroycenter($id)
    {
        DB::table('service_centers')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/center');
    }

    public function destroyadvisor($id)
    {
        DB::table('sale_advisors')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/advisor');
    }

    public function destroysalesman($id)
    {
        DB::table('salesmans')->where('id',$id)->update(['delete_status'=>'1']);
        

        return redirect('/master/salesman');
    }

    

    

    
}
