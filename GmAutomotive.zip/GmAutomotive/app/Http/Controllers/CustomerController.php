<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialList;
use App\VicidialLists;
use App\VicidialCampaign;
use App\VicidialAgentLog; 
use Illuminate\Support\Facades\Input; //header
use Excel;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;
use Carbon\Carbon;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function customeruser($mobile,$user,$listid=0,$campaignid=0,$ingroup=0,$chasis=0,$leadid=0)
    {   

        if (strlen($mobile) > 8) {
            $mobile = substr($mobile, -8);
        }

        $user_info = $user;
        $mobile_number = $mobile;

            $id_account = 0;
            $fname = '';
            $lname = '';
            $mobile2 ='';
            $gender = '';
            $civilid = '';
            $address ='';
            $email = '';
        $cusid = 0;

        if($mobile != '0'){
        $mktargt = MKtargt::selectRaw('count(*) AS cnt, magic')->where('phone','like','%' .$mobile.'%')->groupBy('magic')->get();

        }
        else{

        $mktargt = MKtargt::select('magic','firstnam','surname','phone','phone002','phone004','address001','address002','address003','address004')->where('phone','xxxx_123_xxx')->get();
        
        }

        if(count($mktargt) > 0){
            $cusid = $mktargt[0]->magic;

        }
        //print_r($mktargt[0]->surname); exit(); 

        $cusname = '';
        if($chasis != '0'){
        // if (strlen($chasis) > 6) {
        //     $chasis = substr($chasis, -6);
        // }

        $vehicles = MKvehic::select('magic','regno','chassis')->join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic')->where('mk_00_vehic.chassis',$chasis)->get();
        if(count($vehicles) > 0){
            $cusid = $vehicles[0]->ctmagic;
        }
        }

        $listnames = VicidialLists::select('list_name')->where('list_id',$listid)->get();
        $listname =  'ListName';
        if(count($listnames) > 0){
           $listname =  $listnames[0]->list_name;
        }

        // $mkvehic = MKvehic::select('MAGIC','REGNO','MODELVAR','MODEL','MILEAGE','MOTDATE','LASTSERV','LASTWORK')->join('mk_00_vlink','mk_00_vehic.MAGIC', '=','mk_00_vlink.VEHMAGIC')->addSelect('mk_00_vlink.CTMAGIC as ctmagic')->where('mk_00_vlink.CTMAGIC','231272')->get();


        // $vehhisty = MKhisty::select('date','code','details','miles','invno','wipno','prime','tarmagic','value','accno','company')->where('prime','421150')->where('tarmagic','231272')->get();
        // print_r($vehhisty); exit();

        $csi_questions = DB::table('csi_questions')->where('parent_id','0')->first();

        $enqHTML = '';

        $account = DB::table('account')->where('mobile_number',$mobile)->get();
        if(count($account) > 0){
            $id_account = 0;
            $fname = $account[0]->first_name;
            $lname = $account[0]->last_name;
            $mobile2 = $account[0]->alternate_mobile;
            $gender = $account[0]->gender;
            $civilid = $account[0]->civil_id;
            $address = $account[0]->address;


        $account_comments = DB::table('opportunity')->where('mobile_number',$mobile)->orderBy('id_opp','desc')->get();




        if(count($account_comments) > 0){
        foreach($account_comments as $comment){

            $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_category)->first();
            $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory)->first();
            $enq_category = '';
            $enq_subcategory = '';
            $enq_subcategory2 = '';
            $enq_subcategory3 = '';

             if(!empty($comment->enquiry_subcategory2) || $comment->enquiry_subcategory2 != '0'){

             $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory2)->first();

            if(count($enq_sub_cat2) > 0){
              $enq_subcategory2 = "<br>".$enq_sub_cat2->category_name;
            }

            }

            if(!empty($comment->enquiry_subcategory3) || $comment->enquiry_subcategory3 = '0'){

             $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory3)->first();

            if(count($enq_sub_cat3) > 0){
              $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
            }
             }
            if(count($enq_cat) > 0){
              $enq_category = $enq_cat->category_name;
            }
            if(count($enq_sub_cat) > 0){
              $enq_subcategory = $enq_sub_cat->category_name;
            }

          $enqHTML .='<tr>';
              $enqHTML .='<td>'.$comment->id_opp.'</td>';
              $enqHTML .='<td>'.$comment->id_agent.'</td>';
              $enqHTML .='<td>'.$comment->type_of_profession.'</td>';
              $enqHTML .='<td>'.$comment->date_add.'</td>';
              $enqHTML .='<td>'.$enq_category.'</td>';
              $enqHTML .='<td>'.$enq_subcategory.''.$enq_subcategory2.''.$enq_subcategory3.'</td>';
              $enqHTML .='<td>'.$comment->description.'</td>';
          $enqHTML .='</tr>';


        }
        }

        }
        if($listid == '1005'){
            $leadinfo = VicidialList::where('list_id',$listid)->where('phone_number',$mobile_number)->orderBy('lead_id','desc')->first();
            if($leadinfo){

            $fname = $leadinfo->first_name;
            $lname = '';
            $email = $leadinfo->email;
            }
        }

        $dial_logs = VicidialLog::select('lead_id as closecallid','campaign_id','call_date','phone_number','list_id','status')->where('phone_number',$mobile)->orderBy('lead_id','desc')->get();
        $upscales = DB::table('vehicle_upscales')->get();

        if($listid == '999'){
        //$listname =  ' Incoming';
        $enquiry_categories = DB::table('enquiry_categories')->where('leadid','INBOUND')->where('parent_id','0')->orderBy('order_by','asc')->get();
        }
        else{
        //$listname =  $listname.' - Outgoing';
                $enquiry_categories = DB::table('enquiry_categories')->where('leadid','OUTBOUND')->where('parent_id','0')->orderBy('order_by','asc')->get();
        }
        
        $list_ids = VicidialLists::select('list_id','list_name','campaign_id')->orderBY('list_name','asc')->get();


        $showrooms = DB::table('showrooms')->where('delete_status','0')->orderBy('id','asc')->get();
        $centers = DB::table('service_centers')->where('delete_status','0')->orderBy('id','asc')->get();
        $sourcebusiness = DB::table('source_business')->get();       
        $brands = DB::table('brands')->where('delete_status','0')->orderBy('id','asc')->get();
        $brand_models = DB::table('brand_models')->where('delete_status','0')->orderBy('id','asc')->get();

        //print_r($mktargt); exit();
        
        return view('customer.customer',compact('upscales','mktargt','account','user_info','enquiry_categories','mobile_number','fname','lname','id_account','mobile','mobile2','gender','civilid','address','email','csi_questions','listid','campaignid','ingroup','cusid','cusname','chasis','leadid','listname','showrooms','centers','sourcebusiness','brands','brand_models','enqHTML','dial_logs','list_ids'));
    }



    public function customerregno($regno,$user,$listid=0,$campaignid=0,$ingroup=0,$chasis=0,$leadid=0)
    {
        
        $ctmagic = 0;
        $phone = 0;
        //print_r($regno); exit();
        $registerno = str_replace("__","/",$regno);
        $vehicles = MKvehic::select('magic','regno')->join('mk_00_vlink','mk_00_vehic.MAGIC', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic as ctmagic')->where('mk_00_vehic.regno',$registerno)->get();

        if(count($vehicles) > 0){
        $ctmagic = $vehicles[0]->ctmagic;
        $customer = MKtargt::select('phone004')->where('magic',$ctmagic)->get();
        if(count($customer) > 0){       
        $phone = $customer[0]->phone004;
        }

        } 
        //print_r($customer); exit();
        return redirect('/customer/'.$phone.'/'.$user.'/'.$listid.'/'.$campaignid.'/'.$ingroup.'/'.$chasis.'/'.$leadid);

    }



    public function customercivil($phone,$user,$listid=0,$campaignid=0,$ingroup=0,$chasis=0,$leadid=0)
    {
        
        $ctmagic = 0;
        //print_r($regno); exit();

        if($phone> 0){
        $customer = MKtargt::select('phone004','socialid')->where('socialid',$phone)->get();
        if(count($customer) > 0){       
        $phone = $customer[0]->phone004;
        }

        } 
        //print_r($customer); exit();
        return redirect('/customer/'.$phone.'/'.$user.'/'.$listid.'/'.$campaignid.'/'.$ingroup.'/'.$chasis.'/'.$leadid);

    }

    public function customerchassis($regno,$user,$listid=0,$campaignid=0,$ingroup=0,$chasis=0,$leadid=0)
    {
        
        $ctmagic = 0;
        $phone = 0;
        //print_r($regno); exit();
        $registerno = $regno;
        $chassis = $regno;

        $last5 = MKvehic::select('magic','regno','chassis')->join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic as ctmagic')->where('mk_00_vehic.chassis','like','%' .$regno)->get();

        foreach ($last5 as $last) {
            $chassis = substr($last->chassis, -6);
            if($chassis == $regno){
                $chasis = $last->chassis;

            }
        }
        //print_r($chassis); exit();

        $vehicles = MKvehic::select('magic','regno','chassis')->join('mk_00_vlink','mk_00_vehic.magic', '=','mk_00_vlink.vehmagic')->addSelect('mk_00_vlink.ctmagic as ctmagic')->where('mk_00_vehic.chassis',$chasis)->get();

        if(count($vehicles) > 0){
        $ctmagic = $vehicles[0]->ctmagic;
        $customer = MKtargt::select('phone004')->where('magic',$ctmagic)->get();
        if(count($customer) > 0){       
        $phone = $customer[0]->phone004;
        }

        } 
        //print_r($customer); exit();
        return redirect('/customer/'.$phone.'/'.$user.'/'.$listid.'/'.$campaignid.'/'.$ingroup.'/'.$chasis.'/'.$leadid);

    }

    public function customer_new()
    {
       // echo $mobile;
        if (isset($_GET["mobile"]) && isset($_GET["user"])) {
            $mobile=$_GET["mobile"];
            $user=$_GET["user"];
        return redirect('/customer/'.$mobile.'/'.$user);
        }
        else if (isset($_GET["mobile"])) {
            $mobile=$_GET["mobile"];
        return redirect('/customer/'.$mobile);
        }// echo $mobile;

        $upscales = DB::table('vehicle_upscales')->get();
        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories1 = DB::table('enquiry_categories')->where('parent_id','1')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories2 = DB::table('enquiry_categories')->where('parent_id','2')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories3 = DB::table('enquiry_categories')->where('parent_id','3')->orderBy('id_enquiry_category','asc')->get();
        return view('customer.customer',compact('upscales','enquiry_categories','sub_categories1','sub_categories2','sub_categories3'));
    }


    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->id_account;
        if($id_account == 0){
        $id_account= DB::table('account')->insertGetId(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }
        else{

        DB::table('account')->where('id_account',$id_account)->update(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_update'=>date("Y-m-d H:i:s")]);
        }
        return redirect('/customer/'.$request->mobile.'/'.$request->user_info);
    }

    public function vehstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->vehicle_id;

        if($id_account == 0){

        DB::table('vehicles')->insert(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);
        }
        else{
        DB::table('vehicles')->where('id',$request->vehicle_id)->update(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);

        }
        return redirect('/customer/'.$request->phone_number.'/'.$request->user_info.'/'.$request->listid.'/'.$request->campaignid.'/'.$request->ingroup);
    }


    public function enqstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->enq_account;
        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        //$iduser = DB::table('account')->where('id_account',$id_account)->first();

        if(!empty($request->category)){
        $category = $request->category;
        $subcategory = '';

        $subcategory = "";
        $subcategory2 = "";
        $subcategory3 ="";

        if(!empty($request->subcategory1)){
        $subcategory = $request->subcategory1;
        }
        if(!empty($request->subcategory2)){
        $subcategory2 = $request->subcategory2;
        }
        if(!empty($request->subcategory3)){
        $subcategory3 = $request->subcategory3;
        }

        $appointment = $request->appointment;
        if(!empty($appointment)){
            $appointment_date = date("Y-m-d",strtotime($appointment));
            $appointment_time = date("H:i:s",strtotime($appointment));
        }
        else{
            $appointment_date = '';
            $appointment_time = '';
        }


        $opp_id = DB::table('opportunity')->insertGetId(['id_account'=>$id_account,'enquiry_category'=>$request->category,'enquiry_subcategory'=>$subcategory,'enquiry_subcategory2'=>$subcategory2,'enquiry_subcategory3'=>$subcategory3,'description'=>$request->description,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'id_agent'=>$request->user_info,'id_process_lead'=>$request->leadid,'ingroup'=>$request->ingroup,'id_list'=>$request->listid,'first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->phone_number,'campaign_id'=>$request->campaignid,'alternate_number'=>$request->mobile2,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);

        if($request->apptab == 'Yes'){
        if($subcategory =='4' || $subcategory =='5' || $subcategory =='8' || $subcategory =='112' || $subcategory =='113' || $subcategory =='114' || $subcategory =='115' || $subcategory =='116' || $subcategory =='117' || $subcategory =='127' || $subcategory =='128' || $subcategory =='129' || $subcategory =='130' || $subcategory =='131' || $subcategory =='132' || $subcategory =='133' || $subcategory =='134' || $subcategory =='135' || $subcategory =='136' || $subcategory =='137'){

            $interest = $request->brandmodel;                
            
            if($request->category == '1' || $request->category == '109'){
            $appointmentcode = $request->appointmentcode1;                
            }
            else{
            $appointmentcode = $request->appointmentcode;                
            }
        DB::table('appointments')->insert(['id_account'=>$id_account,'mobile_number'=>$request->phone_number,'source_name'=>$request->source_name,'appointment_datetime'=>$request->appointment,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'salesman'=>$request->salesman,'agentname'=>$request->agent_name,'showroom'=>$request->showroom,'servicecenter'=>$request->servicecenter,'advisorname'=>$request->advisorname,'brand'=>$request->interest,'interest'=>$interest,'appointmenttype'=>$request->appointmenttype,'appointmentcode'=>$appointmentcode,'appbooked'=>$request->apptab,'opp_id'=>$opp_id,'campaign_id'=>$request->campaignid]);
        }
        DB::table('opportunity')->where('id_opp',$opp_id)->update(['appointment_booked'=>$request->apptab]);
        }

        DB::table('account_comments')->insert(['id_account'=>$id_account,'description'=>$request->description,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }

        $id_count = DB::table('account')->where('alg_account',$id_account)->get();
        if(count($id_count) > 0){
        DB::table('account')->where('alg_account',$id_account)->update(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'campaign_id'=>$request->campaignid,'gender'=>$request->gender,'address'=>$request->address,'date_update'=>date("Y-m-d H:i:s")]);
        }
        else{

        DB::table('account')->insertGetId(['alg_account'=>$id_account,'first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'campaign_id'=>$request->campaignid,'gender'=>$request->gender,'address'=>$request->address,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);

        }

        $checklist = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('list_id',$request->listid)->where('status','!=','DA')->where('phone_number',$request->mobile)->orderBy('lead_id','desc')->first();
        //print_r($checklist); exit();
        if ($checklist) {

        $batchno = $checklist->batchno;

        $checklisttarget =  DB::table('target_lists')->where('list_id',$request->listid)->first();
        if ($checklisttarget) {
        $achieved = $checklisttarget->achieved + 1;
        $remaining = $checklisttarget->totaltarget - $achieved;
        if ($remaining > 0) {
            DB::table('target_lists')->where('list_id',$request->listid)->update(['achieved'=>$achieved,'remaining'=>$remaining]);
        }
        else if($remaining == '0'){
            DB::table('target_lists')->where('list_id',$request->listid)->update(['achieved'=>$achieved,'remaining'=>$remaining]);
            VicidialLists::where('list_id',$request->listid)->update(['active'=>'N']);
        }

        }
            
        $checkbatch =  DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$batchno)->first();
        if ($checkbatch) {
        $achieved = $checkbatch->achieved + 1;
        $remaining = $checkbatch->totaltarget - $achieved;
        if ($remaining > 0) {
            DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$batchno)->update(['achieved'=>$achieved,'remaining'=>$remaining]);
        }
        else if($remaining == '0'){
            DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$batchno)->update(['achieved'=>$achieved,'remaining'=>$remaining]);
            VicidialLists::where('list_id',$request->listid)->update(['active'=>'N']);
            DB::table('target_batches')->where('list_id',$request->listid)->where('batchno',$batchno)->update(['active'=>'N']);
        }

        }

        }

        return redirect('/customer/'.$request->phone_number.'/'.$request->user_info.'/'.$request->listid.'/'.$request->campaignid.'/'.$request->ingroup.'/'.$request->chasisid.'/'.$request->leadid);
    }



}
