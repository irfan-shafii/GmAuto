<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Excel;
use Session;
use App\VicidialUsers;
use App\VicidialUserGroup;
use App\VicidialCloserLog;
use App\VicidialLog;
use App\VicidialCampaign;
use App\VicidialCampaignStat;
use App\VicidialAgentLive;
use App\VicidialAgentLog; 
use App\VicidialDialLog;
use App\VicidialHopper;
use App\Average;

class AgentReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
    //print_r(Session::get('campaignid'));   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';
        $campaignids = Session::get('campaignid');
        $usergroupids = Session::get('usergroups');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();

        $usergroups = VicidialUserGroup::select('user_group','group_name');

        if(!empty($usergroupids)){
            $usergroups = $usergroups->whereIn('user_group',explode(",", $usergroupids));
        }
        $usergroups = $usergroups->get();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::select('user','status','talk_sec','pause_sec','wait_sec','dispo_sec','dead_sec','user_group','campaign_id')->whereBetween('event_time',[$fromdate, $todate1]);

        
        if(!empty($campaignids)){
            $vicidial_agent_log = $vicidial_agent_log->whereIn('campaign_id',explode(",", $campaignids));
            $all_sec = $all_sec->whereIn('campaign_id',explode(",", $campaignids));
        }

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name')->get();
        
        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }


        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();

        $divhtml = '';  

            if(count($closer_log) > 0){
                foreach($closer_log as $log){
                  $all_secs = $all_sec->where('user',$log->user);
                  $auto1 = $all_secs->count();
                  $auto2 = $all_secs->where('status',null)->count();
                  $auto = $auto1 - $auto2 ;
                  $talk_sec = $all_secs->sum('talk_sec');
                  $talk_avg = Average::MathZDC($talk_sec,$auto);
                  $pause_sec = $all_secs->sum('pause_sec');
                  $pause_avg = Average::MathZDC($pause_sec,$auto);
                  $wait_sec = $all_secs->sum('wait_sec');
                  $wait_avg = Average::MathZDC($wait_sec,$auto);
                  $dispo_sec = $all_secs->sum('dispo_sec');
                  $dispo_avg = Average::MathZDC($dispo_sec,$auto);
                  $dead_sec = $all_secs->sum('dead_sec');
                  $dead_avg = Average::MathZDC($dead_sec,$auto);
                  $call_time = $talk_sec+$pause_sec+$wait_sec+$dispo_sec;
                  $pause_per = Average::MathPER($pause_sec,$call_time);
                  $wait_per = Average::MathPER($wait_sec,$call_time);
                  $dispo_per = Average::MathPER($dispo_sec,$call_time);
                  $dead_per = Average::MathPER($dead_sec,$call_time);
                  $talk_per = Average::MathPER($talk_sec,$call_time);
                
                  $divhtml .= '<tr class="">';
                    $divhtml .= '<td>'.$log->full_name.'</td>';
                    $divhtml .= '<td>'.$log->user.'</td>';
                    $divhtml .= '<td>'.$auto.'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($call_time).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($wait_sec).'</td>';
                    $divhtml .= '<td>'.$wait_per.'%</td>';
                    $divhtml .= '<td>'.Average::toMinutes($talk_sec).'</td>';
                    $divhtml .= '<td>'.$talk_per.'%</td>';
                    $divhtml .= '<td>'.Average::toMinutes($dispo_sec).'</td>';
                    $divhtml .= '<td>'.$dispo_per.'%</td>';
                    $divhtml .= '<td>'.Average::toMinutes($pause_sec).'</td>';
                    $divhtml .= '<td>'.$pause_per.'%</td>';
                    $divhtml .= '<td>'.Average::toMinutes($dead_sec).'</td>';
                    $divhtml .= '<td>'.$dead_per.'%</td>';
                    $divhtml .= '<td>'.$auto.'</td>';
                  $divhtml .= '</tr>';

              }
          }
      
        //print_r($divhtml); exit();  
        return view('reports.agent_time',compact('divhtml','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }


    public function performance(Request $request)
    {      
    if(empty(Session::get('userid'))){ return redirect('/login'); } 
    //print_r('expression');   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';
        $campaignids = Session::get('campaignid');
        $usergroupids = Session::get('usergroups');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();

        $usergroups = VicidialUserGroup::select('user_group','group_name');

        if(!empty($usergroupids)){
            $usergroups = $usergroups->whereIn('user_group',explode(",", $usergroupids));
        }
        $usergroups = $usergroups->get();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::select('user','status','talk_sec','pause_sec','wait_sec','dispo_sec','dead_sec','user_group','campaign_id')->where('status','!=',null)->whereBetween('event_time',[$fromdate, $todate1]);

        
        if(!empty($campaignids)){
            $vicidial_agent_log = $vicidial_agent_log->whereIn('campaign_id',explode(",", $campaignids));
            $all_sec = $all_sec->whereIn('campaign_id',explode(",", $campaignids));
        }

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();


        $divhtml = '';  
        $divhtml1 = '';  
        // print_r($closer_log."<br>===================<br>");
        // print_r($all_sec);
        // exit();
            if(count($closer_log) > 0){
                foreach($closer_log as $log){

        $ainbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->where('user',$log->user)->count();
        $amissed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','DROP')->where('user',$log->user)->count();
        $aoutbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->where('user',$log->user)->count();

                  $all_secs = $all_sec->where('user',$log->user);
                  $auto1 = $all_secs->count();
                  $auto2 = $all_secs->where('status',null)->count();
                  $auto = $auto1 - $auto2 ;

                  $talk_sec = $all_secs->sum('talk_sec');
                  $talk_avg = Average::MathZDC($talk_sec,$auto);
                  $pause_sec = $all_secs->sum('pause_sec');
                  $pause_avg = Average::MathZDC($pause_sec,$auto);
                  $wait_sec = $all_secs->sum('wait_sec');
                  $wait_avg = Average::MathZDC($wait_sec,$auto);
                  $dispo_sec = $all_secs->sum('dispo_sec');
                  $dispo_avg = Average::MathZDC($dispo_sec,$auto);
                  $dead_sec = $all_secs->sum('dead_sec');
                  $dead_avg = Average::MathZDC($dead_sec,$auto);
                  $call_time = $talk_sec+$pause_sec+$wait_sec+$dispo_sec;
                  $pause_time = $call_time-$pause_sec;
                
                  $divhtml .= '<tr class="">';
                    $divhtml .= '<td>'.$log->full_name.'</td>';
                    $divhtml .= '<td>'.$log->user.'</td>';
                    $divhtml .= '<td>'.$log->user_group.'</td>';
                    $divhtml .= '<td>'.$auto.'</td>';
                    $divhtml .= '<td>'.$ainbound.'</td>';
                    $divhtml .= '<td>'.$aoutbound.'</td>';
                    $divhtml .= '<td>'.$amissed.'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($call_time).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($pause_sec).'</td>';
                    $divhtml .= '<td>'.gmdate("H:i:s", $pause_avg).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($wait_sec).'</td>';
                    $divhtml .= '<td>'.gmdate("H:i:s", $wait_avg).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($talk_sec).'</td>';
                    $divhtml .= '<td>'.gmdate("H:i:s", $talk_avg).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($dispo_sec).'</td>';
                    $divhtml .= '<td>'.gmdate("H:i:s", $dispo_avg).'</td>';
                    $divhtml .= '<td>'.Average::toMinutes($dead_sec).'</td>';
                    $divhtml .= '<td>'.gmdate("H:i:s", $dead_avg).'</td>';
                    $divhtml .= '<td>'.$auto.'</td>';
                  $divhtml .= '</tr>';



                
                  $divhtml1 .= '<tr class="">';
                    $divhtml1 .= '<td>'.$log->full_name.'</td>';
                    $divhtml1 .= '<td>'.$log->user.'</td>';
                    $divhtml1 .= '<td>'.Average::toMinutes($call_time).'</td>';
                    $divhtml1 .= '<td>'.Average::toMinutes($pause_sec).'</td>';
                    $divhtml1 .= '<td>'.Average::toMinutes($pause_time).'</td>';
                  $divhtml1 .= '</tr>';

              }
          }
      
        //print_r($usergroup); exit();  
        return view('reports.agent',compact('divhtml','divhtml1','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }


    public function status(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
    //print_r('expression');   exit();  
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';
        $campaignids = Session::get('campaignid');
        $usergroupids = Session::get('usergroups');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));


        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();

        $usergroups = VicidialUserGroup::select('user_group','group_name');

        if(!empty($usergroupids)){
            $usergroups = $usergroups->whereIn('user_group',explode(",", $usergroupids));
        }
        $usergroups = $usergroups->get();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);       
        
        if(!empty($campaignids)){
            $vicidial_agent_log = $vicidial_agent_log->whereIn('campaign_id',explode(",", $campaignids));
            $all_sec = $all_sec->whereIn('campaign_id',explode(",", $campaignids));
        }

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();
      
        //print_r($usergroup); exit();  
        return view('reports.agent_status',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }

    public function team(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
    //print_r('expression');   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';
        $campaignids = Session::get('campaignid');
        $usergroupids = Session::get('usergroups');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));


        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();

        $usergroups = VicidialUserGroup::select('user_group','group_name');

        if(!empty($usergroupids)){
            $usergroups = $usergroups->whereIn('user_group',explode(",", $usergroupids));
        }
        $usergroups = $usergroups->get();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);     
        
        if(!empty($campaignids)){
            $vicidial_agent_log = $vicidial_agent_log->whereIn('campaign_id',explode(",", $campaignids));
            $all_sec = $all_sec->whereIn('campaign_id',explode(",", $campaignids));
        }

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();
      
        //print_r($usergroup); exit();  
        return view('reports.team',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
