<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\User;
use DB;
use App\VicidialUser;
use App\VicidialUserGroup;
use App\VicidialCampaign;
use App\VicidialLists;
use App\VicidialList;  

class TargetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function campaign(Request $request,$id=0)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }


        $campaign_id = '';
        $campaignids = Session::get('campaignid');

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');
        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->orderBY('campaign_name','asc')->get();

        return view('target.campaign',compact('campaigns'));
    }

    public function index(Request $request,$id=0)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }

        $campaign_id = '';
        $list_id = '';
        $description = '';
        $campaignids = Session::get('campaignid');
        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');
        $lists = VicidialLists::select('list_id','list_name','campaign_id');
        $target_lists = DB::table('target_lists');
        if(!empty($campaignids)){
            $lists = $lists->whereIn('list_id',explode(",", $listids));
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
            $target_lists = $target_lists->whereIn('list_id',explode(",", $listids));
        }
        if(!empty($request->campaigns)){
            $campaign_id = $request->campaigns;
            $lists = $lists->where('campaign_id',$campaign_id);
            $target_lists = $target_lists->where('campaign_id',$campaign_id);
        }
        if(!empty($request->lists)){
            $list_id = $request->lists;
            $target_lists = $target_lists->where('list_id',$list_id);
        }

        if ($request->exportstatus == '1') {

                $remaining = $request->settarget;
                $achieved = 0;  
        if (!empty($request->lists)) {
            $checklistid =  DB::table('target_lists')->where('list_id',$request->lists)->first();
            if(empty($checklistid)){     
                DB::table('target_lists')->insert(['list_id'=>$request->lists,'campaign_id'=>$request->campaigns,'totaltarget'=>$request->settarget,'achieved'=>$achieved,'remaining'=>$remaining]);
               
            $description = 'List target inserted with '.$request->settarget.' target(s)'; 
            } 
            else{ 

                $achieved = $checklistid->achieved;    
                $remaining = $request->settarget - $achieved;      
                DB::table('target_lists')->where('list_id',$request->lists)->update(['campaign_id'=>$request->campaigns,'totaltarget'=>$request->settarget,'achieved'=>$achieved,'remaining'=>$remaining]);
            $description = 'List target updated '.$checklistid->totaltarget.' to '.$request->settarget; 

            }     
            DB::table('target_logs')->insert(['listid'=>$request->lists,'description'=>$description,'created_by'=>Session::get('userid')]);
        }
        }


        $lists = $lists->orderBY('list_name','asc')->get();
        $campaigns = $campaigns->orderBY('campaign_name','asc')->get();
        $target_lists = $target_lists->orderBy('id','desc')->get();  
        return view('target.list',compact('campaigns','lists','target_lists','campaign_id','list_id'));
    }

    public function batch(Request $request,$id=0)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        $campaign_id = '';
        $list_id = '';
        $batchno = '';
        $campaignids = Session::get('campaignid');
        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');
        $lists = VicidialLists::select('list_id','list_name','campaign_id');
        $target_lists = DB::table('target_batches');
        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('lead_id','>','0')->where('batchno','!=','');
        if(!empty($campaignids)){
            $lists = $lists->whereIn('list_id',explode(",", $listids));
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
            $target_lists = $target_lists->whereIn('list_id',explode(",", $listids));
            $batches = $batches->whereIn('list_id',explode(",", $listids));
        }
        if(!empty($request->campaigns)){
            $campaign_id = $request->campaigns;
            $lists = $lists->where('campaign_id',$campaign_id);
            $target_lists = $target_lists->where('campaign_id',$campaign_id);
        }
        if(!empty($request->lists)){
            $list_id = $request->lists;
            $target_lists = $target_lists->where('list_id',$list_id);
        }
        if(!empty($request->batchno)){
            $batchno = $request->batchno;
            $target_lists = $target_lists->where('batchno',$batchno);
            $batches = $batches->where('batchno',$batchno);
        }
        $batches = $batches->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        $lists = $lists->orderBY('list_name','asc')->get();
        $campaigns = $campaigns->orderBY('campaign_name','asc')->get();
        $target_lists = $target_lists->skip(0)->take(100)->orderBy('id','desc')->get();  
        return view('target.batch',compact('campaigns','lists','batches','target_lists','campaign_id','list_id','batchno'));
    }

    public function logs(Request $request,$id=0)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $fromdate = date("Y-m-d");
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        $campaign_id = '';
        $list_id = '';
        $batchno = '';
        $campaignids = Session::get('campaignid');
        $listids = '';
        if(!empty($campaignids)){
            $lists = VicidialLists::select('list_id','list_name','campaign_id')->whereIn('campaign_id',explode(",", $campaignids))->get();
            if(count($lists) > 0) {
                foreach ($lists as $list) {
                    $listgrps[] = $list->list_id;
                }
            $listids = implode(",", $listgrps);
            }
        }

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');
        $lists = VicidialLists::select('list_id','list_name','campaign_id');
        $target_lists = DB::table('target_logs');
        $batches = VicidialList::whereBetween('modify_date',[$fromdate, $todate1])->where('lead_id','>','0')->where('batchno','!=','');
        if(!empty($campaignids)){
            $lists = $lists->whereIn('list_id',explode(",", $listids));
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
            $target_lists = $target_lists->whereIn('list_id',explode(",", $listids));
            $batches = $batches->whereIn('list_id',explode(",", $listids));
        }
        if(!empty($request->lists)){
            $list_id = $request->lists;
            $target_lists = $target_lists->where('listid',$list_id);
        }
        if(!empty($request->batchno)){
            $batchno = $request->batchno;
            $target_lists = $target_lists->where('batchid',$batchno);
            $batches = $batches->where('batchno',$batchno);
        }
        $batches = $batches->select('batchno', DB::raw('count(*) as batches'))->groupBy('batchno')->get();
        $lists = $lists->orderBY('list_name','asc')->get();
        $campaigns = $campaigns->orderBY('campaign_name','asc')->get();
        $target_lists = $target_lists->skip(0)->take(100)->orderBy('id','desc')->get();  
        return view('target.logs',compact('campaigns','lists','batches','target_lists','campaign_id','list_id','batchno'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit(); 
        $description = '';
        $id = $request->targetid;
        $checkid =  DB::table('target_lists')->where('id',$id)->first();
        if($checkid){
        $remaining = $request->target - $checkid->achieved;
        $achieved = $request->target - $remaining;
            DB::table('target_lists')->where('id',$id)->update(['totaltarget'=>$request->target,'achieved'=>$achieved,'remaining'=>$remaining]);

        $description = 'List target updated '.$checkid->totaltarget.' to '.$request->target;
        DB::table('target_logs')->insert(['listid'=>$checkid->list_id,'description'=>$description,'created_by'=>Session::get('userid')]); 
        } 
        return redirect('/target/list');
    }


    public function batchstore(Request $request)
    {
        //print_r($request->all()); exit(); 
        $description = '';
        $id = $request->targetid;
        $checkid =  DB::table('target_batches')->where('id',$id)->first();
        if($checkid){
        $remaining = $request->target - $checkid->achieved;
        $achieved = $request->target - $remaining;
            DB::table('target_batches')->where('id',$id)->update(['totaltarget'=>$request->target,'achieved'=>$achieved,'remaining'=>$remaining]);

        $description = 'Batch target updated '.$checkid->totaltarget.' to '.$request->target;
        DB::table('target_logs')->insert(['listid'=>$checkid->list_id,'batchid'=>$checkid->batchno,'description'=>$description,'created_by'=>Session::get('userid')]); 

        } 
        return redirect('/target/batch');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {      
        $listid = DB::table('target_lists')->where('id',$id)->first();

        $listnames = VicidialLists::select('list_name')->where('list_id',$listid->list_id)->first();
        $listname =  '';
        if($listnames){
        $listname =  $listnames->list_name;
        }

        DB::table('target_lists')->where('id',$id)->update(['achieved'=>'0','remaining'=>'0']);
        DB::table('target_batches')->where('list_id',$listid->list_id)->update(['active'=>'N']);

        $description = 'List target was resetted. ';
        DB::table('target_logs')->insert(['listid'=>$listid->list_id,'description'=>$description,'created_by'=>Session::get('userid')]); 

        return redirect('/target/list');
    }
}
