<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialRecord;

class RecordingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $campaignids = Session::get('campaignid');

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
        $dial_logs = VicidialLog::whereBetween('call_date',[$fromdate, $todate1]);
        if(!empty($campaignids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $campaignids));
        }
        $dial_logs = $dial_logs->get();

        if(!empty($request->phone)){
            $phone = $request->phone;
            $dial_logs = $dial_logs->where('phone_number',$phone);
        }
        //print_r($dial_logs); exit();
        return view('record.index',compact('dial_logs','fromdate','todate','phone'));
    }

    public function inbound(Request $request)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $fromdate = date('Y-m-d');
        $todate = date('Y-m-d');
        $phone = '';
        $campaignids = Session::get('campaignid');


        $ingroupids = '';
        if(!empty($campaignids)){
            $ingroups = DB::table('user_campaigns')->select('campaigns','ingroups')->whereIn('campaigns',explode(",", $campaignids))->get();
            if(count($ingroups) > 0) {
                foreach ($ingroups as $ing) {
                    $ingrps[] = $ing->ingroups;
                }
            $ingroupids = implode(",", $ingrps);
            //print_r($ingroupids); exit();
            }
        }

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts1 = explode('-',$todate);
            $todate = $parts1[2] . '-' . $parts1[0] . '-' . $parts1[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));
        $dial_logs = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP');
        if(!empty($ingroupids)){
            $dial_logs = $dial_logs->whereIn('campaign_id',explode(",", $ingroupids));
        }
        $dial_logs = $dial_logs->orderBY('closecallid','desc')->get();

        if(!empty($request->phone)){
            $phone = $request->phone;
            $dial_logs = $dial_logs->where('phone_number',$phone);
        }
        //print_r($dial_logs); exit();
        return view('record.inbound',compact('dial_logs','fromdate','todate','phone'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
