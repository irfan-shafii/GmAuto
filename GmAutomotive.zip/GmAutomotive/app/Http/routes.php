<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','ReportsController@index')->name('dashboard');
Route::post('/home','ReportsController@index')->name('dashboard');

Route::get('/dashboard','ReportsController@index')->name('dashboard');
Route::post('/dashboard','ReportsController@index')->name('dashboard');
Route::get('/dashboard/{monthly}','ReportsController@index')->name('dashboard1');
Route::post('/dashboard/{monthly}','ReportsController@index')->name('dashboard1');

Route::get('/dashboard1','ReportsController@index1')->name('dashboard1');
Route::post('/dashboard1','ReportsController@index1')->name('dashboard1');

Route::get('/dashboard2','ReportsController@index2')->name('dashboard2');
Route::post('/dashboard2','ReportsController@index2')->name('dashboard2');

Route::post('/dashboard_export','ReportsController@export');

Route::get('/login', function () {
    return view('login');
});
Route::get('/test', function () {
    return view('test');
});

Route::get('/list/remaining', function () {
    return view('target.remaining');
});

Route::post('/login/store','LoginController@store');
Route::get('/login/{id}','LoginController@show')->name('login');
Route::post('/login/{id}/password','LoginController@password');
Route::get('/logout','LoginController@logout');

Route::get('/customers','LoginController@customer')->name('customers');
Route::get('/users','LoginController@index')->name('users');
Route::get('/users/create','LoginController@create')->name('users');
Route::get('/users/edit/{id}','LoginController@edit')->name('users');
Route::get('/users/delete/{id}','LoginController@delete')->name('users');
Route::post('/users/{id}/update','LoginController@update');
Route::post('/users/store','LoginController@userstore');
Route::get('/users/campaigns','LoginController@campaign')->name('users-campaign');
Route::post('/users/campaignstore','LoginController@campaignstore');
Route::get('/users/groups','LoginController@usergroups')->name('users-group');
Route::get('/users/groups/{group}','LoginController@usergroups')->name('users-group');
Route::post('/users/groupstore','LoginController@groupstore');
Route::get('/usergroups/campaigns','LoginController@campaigngroup')->name('group-campaign');
Route::post('/users/usergroupstore','LoginController@usergroupstore');

Route::get('/history/{docref}','DocumentController@history');
Route::post('/showvehstatus','DocumentController@showvehstatus');

//CustomerController
Route::get('/customer','CustomerController@customer_new');
Route::get('/customer/{mobile}','CustomerController@customer');
Route::post('/customer/store','CustomerController@store');
Route::post('/enquiry/store','CustomerController@enqstore');
Route::post('/customervehicle/store','CustomerController@vehstore');
Route::get('/customer/{mobile}/{user}','CustomerController@customeruser');
Route::get('/customer_old/{mobile}/{user}','CustomerController@customerold');
Route::get('/customer/{mobile}/{user}/{listid}/{campaignid}/{ingroup}','CustomerController@customeruser');
Route::get('/customer/{mobile}/{user}/{listid}/{campaignid}/{ingroup}/{chassis}','CustomerController@customeruser');
Route::get('/customer/{mobile}/{user}/{listid}/{campaignid}/{ingroup}/{chassis}/{leadid}','CustomerController@customeruser');
Route::get('/customer_regno/{regno}/{user}/{listid}/{campaignid}/{ingroup}/{chassis}/{leadid}','CustomerController@customerregno');
Route::get('/customer_civil/{regno}/{user}/{listid}/{campaignid}/{ingroup}/{chassis}/{leadid}','CustomerController@customercivil');
Route::get('/customer_chasis/{regno}/{user}/{listid}/{campaignid}/{ingroup}/{chassis}/{leadid}','CustomerController@customerchassis');

//ReportsController
Route::get('/inquiries','ReportsController@inquiries')->name('inquiries');
Route::post('/inquiries','ReportsController@inquiries')->name('inquiries');
Route::get('/inquiries/view/{id}','ReportsController@viewinquiry')->name('inquiries');
Route::get('/appointments/{id}','ReportsController@vappointments')->name('appointments');
Route::get('/useranswers','ReportsController@useranswers')->name('user-answer');
Route::post('/useranswers','ReportsController@useranswers')->name('user-answer');
Route::get('/useranswers/{id}','ReportsController@vuseranswers')->name('user-answer');
Route::get('/appointments','ReportsController@appointments')->name('appointments');
Route::post('/appointments','ReportsController@appointments')->name('appointments');


Route::get('/auto-dial','ReportsController@auto_dial')->name('auto-dial');
Route::get('/auto-dial1','ReportsController@auto_dial1')->name('auto-dial1');
Route::post('/auto/upload','ReportsController@upload');
Route::get('/autoupload-dial','ReportsController@auto_upload')->name('auto-upload');
Route::post('/autoupload/upload','ReportsController@autodial_upload');
Route::post('/autoupload/folder','ReportsController@autodial_folder');


//AjaxController
Route::post('/getcategory','AjaxController@getcategory');
Route::post('/customerinfo','AjaxController@customerinfo');
Route::post('/vehicleinfo','AjaxController@vehicleinfo');
Route::post('/getcsi','AjaxController@getcsi');
Route::post('/getquestion','AjaxController@getquestion');
Route::post('/getprevquestion','AjaxController@getprevquestion');
Route::post('/edit_csi','AjaxController@edit_csi');
Route::post('/editqueston','AjaxController@editqueston');
Route::post('/gettxtdocument','AjaxController@gettxtdocument');
Route::post('/getsalesman','AjaxController@getsalesman');
Route::post('/getadvisor','AjaxController@getadvisor');
Route::post('/getlistids','AjaxController@getlistids');
Route::post('/getliveagents','AjaxController@getliveagents');
Route::post('/changestatus','AjaxController@changestatus');
Route::post('/getusergroup','AjaxController@getusergroup');
Route::post('/getbatch','AjaxController@getbatch');
Route::post('/getlistbatch','AjaxController@getlistbatch');
Route::post('/changebatchstatus','AjaxController@changebatchstatus');
Route::post('/getadvisorname','AjaxController@getadvisorname');
Route::post('/getlisttarget','AjaxController@getlisttarget');
Route::post('/getbatchtarget','AjaxController@getbatchtarget');
Route::post('/getmodel','AjaxController@getmodel');
Route::post('/getbrand','AjaxController@getbrand');

//FordController
Route::get('/ford/customer','FordController@customer_new');
Route::get('/ford/customer/{mobile}','FordController@customer');
Route::post('/ford/customer/store','FordController@store');
Route::post('/ford/enquiry/store','FordController@enqstore');
Route::post('/ford/customervehicle/store','FordController@vehstore');
Route::get('/ford/customer/{mobile}/{user}','FordController@customeruser');
Route::get('/ford/customer_old/{mobile}/{user}','FordController@customerold');
Route::get('/ford/customer/{mobile}/{user}/{listid}/{campaignid}/{ingroup}','FordController@customeruser');
Route::get('/ford/customer_regno/{regno}/{user}/{listid}/{campaignid}/{ingroup}','FordController@customerregno');
Route::get('/ford/customer_chasis/{regno}/{user}/{listid}/{campaignid}/{ingroup}','FordController@customerchassis');


//FordAjaxController
Route::post('/ford/getcategory','FordAjaxController@getcategory');
Route::post('/ford/customerinfo','FordAjaxController@customerinfo');
Route::post('/ford/vehicleinfo','FordAjaxController@vehicleinfo');
Route::post('/ford/getcsi','FordAjaxController@getcsi');
Route::post('/ford/getquestion','FordAjaxController@getquestion');
Route::post('/ford/edit_csi','FordAjaxController@edit_csi');
Route::post('/ford/editqueston','FordAjaxController@editqueston');
Route::post('/ford/gettxtdocument','FordAjaxController@gettxtdocument');
Route::post('/ford/getsalesman','FordAjaxController@getsalesman');
Route::post('/ford/getadvisor','FordAjaxController@getadvisor');


Route::get('/target/campaign','TargetController@campaign')->name('target-campaign');
Route::get('/target/list','TargetController@index')->name('target-list');
Route::post('/target/list','TargetController@index')->name('target-list');
Route::get('/target/list/{id}','TargetController@index')->name('target-list');
Route::get('/target/{id}/reset','TargetController@destroy')->name('target-list');
Route::post('/target/liststore','TargetController@store');
Route::get('/target/batch','TargetController@batch')->name('target-batch');
Route::post('/target/batch','TargetController@batch')->name('target-batch');
Route::get('/target/batch/{id}','TargetController@batch')->name('target-batch');
Route::post('/target/batchstore','TargetController@batchstore');
Route::get('/target/logs','TargetController@logs')->name('target-logs');
Route::post('/target/logs','TargetController@logs')->name('target-logs');


Route::get('/vehicle','VehicleController@index')->name('vehicle-list');
Route::get('/vehicle/create','VehicleController@create')->name('vehicle-new');
Route::get('/vehicle/{id}','VehicleController@show')->name('vehicle-list');
Route::post('/vehicle/store','VehicleController@store');
Route::post('/vehicle/description','VehicleController@description');
Route::get('/vehicle/{id}/edit','VehicleController@edit')->name('vehicle-list');
Route::post('/vehicle/{id}/update','VehicleController@update');


Route::get('/upscale','UpscaleController@index')->name('upscale-list');
Route::get('/upscale/create','UpscaleController@create')->name('upscale-new');
Route::get('/upscale/{id}','UpscaleController@show')->name('upscale-list');
Route::post('/upscale/store','UpscaleController@store');
Route::get('/upscale/{id}/edit','UpscaleController@edit')->name('upscale-list');
Route::post('/upscale/{id}/update','UpscaleController@update');


Route::get('/report/outbound','CallLogsReportController@index')->name('outbound-report');
Route::post('/report/outbound','CallLogsReportController@index')->name('outbound-report');
Route::get('/report/inbound','CallLogsReportController@inbound')->name('inbound-report');
Route::post('/report/inbound','CallLogsReportController@inbound')->name('inbound-report');
Route::get('/report/missed','CallLogsReportController@missed')->name('missed-report');
Route::post('/report/missed','CallLogsReportController@missed')->name('missed-report');
Route::get('/callapi','CallLogsReportController@callapi');
Route::get('/callapi2','CallLogsReportController@callapi2');


Route::get('/report/agent/time','AgentReportController@index')->name('agent-time');
Route::post('/report/agent/time','AgentReportController@index')->name('agent-time');

Route::get('/report/agent/performance','AgentReportController@performance')->name('agent-performance');
Route::post('/report/agent/performance','AgentReportController@performance')->name('agent-performance');

Route::get('/report/agent/status','AgentReportController@status')->name('agent-status');
Route::post('/report/agent/status','AgentReportController@status')->name('agent-status');

Route::get('/report/team/performance','AgentReportController@team')->name('team-performance');
Route::post('/report/team/performance','AgentReportController@team')->name('team-performance');


Route::get('/report/call_log','CallLogsReportController@call_log')->name('call-log');
Route::post('/report/call_log','CallLogsReportController@call_log')->name('call-log');

Route::get('/leads/list','ListManagementReportController@index')->name('lead-list');
Route::post('/leads/list','ListManagementReportController@index')->name('lead-list');
Route::get('/leads/list/{userid}','ListManagementReportController@resetid')->name('lead-list');
Route::get('/list/status','ListManagementReportController@status')->name('lead-status');
Route::post('/list/status','ListManagementReportController@status')->name('lead-status');
Route::get('/list/batch','ListManagementReportController@batch')->name('lead-batch');
Route::post('/list/batch','ListManagementReportController@batch')->name('lead-batch');


Route::get('/record/outbound','RecordingController@index')->name('outbound-record');
Route::post('/record/outbound','RecordingController@index')->name('outbound-record');
Route::get('/record/inbound','RecordingController@inbound')->name('inbound-record');
Route::post('/record/inbound','RecordingController@inbound')->name('inbound-record');

Route::get('/master/events','MasterController@events')->name('master-events');
Route::post('/master/events/store','MasterController@eventstore');
Route::get('/master/events/{id}/delete','MasterController@destroyevent')->name('master-events');
Route::get('/master/campaigns','MasterController@campaigns')->name('master-campaigns');
Route::post('/master/campaigns/store','MasterController@campaignstore');
Route::get('/master/campaigns/{id}/delete','MasterController@destroycampaigns')->name('master-campaigns');
Route::get('/master/showroom','MasterController@showroom')->name('master-showroom');
Route::post('/master/showroom/store','MasterController@showroomstore');
Route::get('/master/showroom/{id}/delete','MasterController@destroyshowroom')->name('master-showroom');
Route::get('/master/salesman','MasterController@salesman')->name('master-salesman');
Route::get('/master/salesman/{id}/delete','MasterController@destroysalesman')->name('master-salesman');
Route::post('/master/salesman/store','MasterController@salesmanstore');
Route::get('/master/center','MasterController@center')->name('master-center');
Route::post('/master/center/store','MasterController@centerstore');
Route::get('/master/center/{id}/delete','MasterController@destroycenter')->name('master-center');
Route::get('/master/advisor','MasterController@advisor')->name('master-advisor');
Route::post('/master/advisor/store','MasterController@advisorstore');
Route::get('/master/advisor/{id}/delete','MasterController@destroyadvisor')->name('master-advisor');
Route::get('/master/brands','MasterController@brands')->name('master-brands');
Route::post('/master/brands/store','MasterController@brandstore');
Route::get('/master/brands/{id}/delete','MasterController@destroybrand')->name('master-brands');
Route::get('/master/models','MasterController@models')->name('master-models');
Route::post('/master/models/store','MasterController@modelstore');
Route::get('/master/models/{id}/delete','MasterController@destroymodel')->name('master-models');
