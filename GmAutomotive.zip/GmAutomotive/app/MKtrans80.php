<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKtrans80 extends Model
{
	protected $connection = 'mysql3';
    protected  $table="mk_80_histy";
}
