<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKnewst80 extends Model
{
	protected $connection = 'mysql4';
    protected  $table="vs_80_newst";
}
