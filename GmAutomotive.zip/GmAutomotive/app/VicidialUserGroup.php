<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialUserGroup extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_user_groups";
    public $timestamps = false;
}
