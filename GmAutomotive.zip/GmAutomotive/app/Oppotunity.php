<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Oppotunity extends Model
{
	protected $connection = 'mysql4';
    protected  $table="opportunity";
}
