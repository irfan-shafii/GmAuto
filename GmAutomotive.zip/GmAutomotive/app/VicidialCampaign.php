<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialCampaign extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_campaigns";
    public $timestamps = false;
}
