<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKvlink80 extends Model
{
	protected $connection = 'mysql4';
    protected  $table="mk_80_vlink";
}
