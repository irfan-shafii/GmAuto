<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehStatus extends Model
{
	//protected $connection = 'mysql3';
    protected  $table="so_00_wstat";
}
